<?php    
    session_start();

    if (!isset($_SESSION["alkalmazott_azonosito"]))
        {
            header("location: index.php");
            exit;
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hibás bejelentkezés</title>
    <link href="tools/alap.css" type="text/css" rel="stylesheet">
</head>
<body>    
<div class="hiba-container">
    <h2><?php echo $_SESSION["hiba"] . " " . $_SESSION["alkalmazott_azonosito"];?></h2>
    <br>
    <button onclick="window.location.href='index.php'">Vissza a belépési oldalra!</button>
</div>
</body>
</html>