<?php
    require_once "tools/db_params.php";

    session_start();
    
    if (!isset($_SESSION["alkalmazott_azonosito"]))
        {
            header("location: index.php");
            exit;
        }

    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8");

    if ($conn->connect_error) {
        die(json_encode(["error" => "Kapcsolódási hiba"]));
    }

    $lekert_datum = $_SESSION['leker_datum'] ?? date_create(date("Y-m-d"));

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['honap-ertek'])) {
            $lekert_datum = date_create(date("Y") . "-" . $_POST['honap-ertek'] . "-1");
            $_SESSION['leker_datum'] = $lekert_datum;
        }
        if ((isset($_POST['alk_munk_nyilv_az'])) && (isset($_POST['eves_munkaido_naptar_azonosito'])) && (isset($_POST['gomb']))) {
            if ($_POST['gomb'] == 'uj') {   
                $uj_adat = true;
                $modositas = false;
            }
            elseif ($_POST['gomb'] == 'modositas') {
                $uj_adat = false;
                $modositas = true;                
            }
            elseif ($_POST['gomb'] == 'uj_mentes') {
                $uj_adat = false;
                $modositas = false;
                adatok_mentese($conn,true);
            }
            elseif ($_POST['gomb'] == 'modositas_mentes') {
                $uj_adat = false;
                $modositas = false;
                adatok_mentese($conn,false);
            }
        }
    }

    $honapok = array("január"=>"01", "február"=>"02", "március"=>"03", "április"=>"04", "május"=>"05", "június"=>"06", "július"=>"07", "augusztus"=>"08", "szeptember"=>"09", "október"=>"10", "november"=>"11", "december"=>"12");    
    
    $sql = "select * from alkalmazott WHERE alkalmazott_azonosito = ?;";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION["alkalmazott_azonosito"]);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $vezeto = ($row['vezeto'] === 'I') ? true : false;
    $home_office = ($row['homeoffice_lehetoseg'] === 'I') ? true : false;
    $belepes_datuma = $row['belepes_datuma'] ?? '';
    $kilepes_datuma = $row['kilepes_datuma'] ?? '';

    $sql = "select szuletesi_nev from alkalmazott WHERE alkalmazott_azonosito = ?;";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $row['engedelyezo']);
    $stmt->execute();
    $result = $stmt->get_result();  
    $row2 = $result->fetch_assoc();
    $engedelyezo_neve = $row2['szuletesi_nev'] ?? '-';

    $sql = "select * from alkalmazott_eves_szabadsaga WHERE alkalmazott_azonosito = ? AND ev = ?;";
    $stmt = $conn->prepare($sql);
    $ev = date("Y");
    $stmt->bind_param("ii", $_SESSION["alkalmazott_azonosito"],$ev);
    $stmt->execute();
    $result = $stmt->get_result();
    $eves_szabadsag = $result->fetch_assoc();

    $sql = "select felhasznalt_szabadsag_homeoffice(?,?,?);";
    $tipus = 'szabadság';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iis", $_SESSION["alkalmazott_azonosito"],$ev,$tipus);
    $stmt->execute();
    $result = $stmt->get_result();
    $f_szab = $result->fetch_all();
    $felhasznalt_szabadsag = $f_szab['0']['0'];
    $felhasznalhato_szabadsag = $eves_szabadsag['szabadnapok_szama'] - $felhasznalt_szabadsag;

    $tipus = 'home office';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iis", $_SESSION["alkalmazott_azonosito"],$ev,$tipus);
    $stmt->execute();
    $result = $stmt->get_result();
    $i_ho = $result->fetch_all();
    $igenybevett_homeoffice = $i_ho['0']['0'];

    $sql = "call havi_jelenleti(?, ?);";
    $datum = date_format($lekert_datum,"Y-m-d");
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $_SESSION["alkalmazott_azonosito"], $datum);
    $stmt->execute();
    $result = $stmt->get_result();
    $naptar = $result->fetch_all();
    $stmt->close();
    
    function adatok_mentese($conn,$uj)
    {
        if ($uj) {
            $sql = "call alkalmazotti_munkaido_felvitele(?,?,?,?,?);";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iisss",$_SESSION['alkalmazott_azonosito'],$_POST['eves_munkaido_naptar_azonosito'],$_POST['munk_kezd'],$_POST['munk_vege'],$_POST['tipus']);
        } else {
            $sql = "call alkalmazotti_munkaido_modositasa(?,?,?,?,?,?);";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iisssi",$_SESSION['alkalmazott_azonosito'],$_POST['eves_munkaido_naptar_azonosito'],$_POST['munk_kezd'],$_POST['munk_vege'],$_POST['tipus'],$_POST['alk_munk_nyilv_az']);
        }
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            echo "<script>console.log('Sikeres módosítás!');</script>";
        } else {
            echo "<script>console.log('A módosítás sikertelen!');</script>";
        }
        $stmt->close();
    }

?>


<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Munkaidő nyilvántartás</title>
    <link href="tools/nyilvantarto.css" type="text/css" rel="stylesheet">
    
    <script>
        function ujIgenyles(gomb) {
            const alkmId = <?php echo json_encode($_SESSION['alkalmazott_azonosito'] ?? null); ?>;

            const kuldendoAdat = {
                p_alk_id: alkmId,
            };
            
            fetch('igenyles.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(kuldendoAdat)
            })
        }

        function ellenoriz() {
            const kezd = document.getElementById('munk_kezd').value.trim();
            const vege = document.getElementById('munk_vege').value.trim();
            const tipus = document.getElementById('tipus').value.trim();
            const hibaUzenet = document.getElementById('hibaUzenet');

            if (tipus === 'ledolgozott nap') {
                if ((kezd === '') || (vege === '') || (kezd >= vege )) {
                    hibaUzenet.textContent = 'Hibás időpont(ok) megadása!';
                    return false;
                }
            } 
            hibaUzenet.textContent = '';
            return true;
        }
    </script>

    </head>
    <body>           
        <div class = "fejlec">
            <div class = "alkalmazott-adatai">
                <div class = "adat_fejlec"> Személyi adatok </div>
                <div class = "adat"> Név: <?php echo $row['szuletesi_nev']; ?> </div>
                <div class = "adat"> Közvetlen felettes: <?php echo $engedelyezo_neve; ?> </div>
                <div class = "adat"> Mai dátum: <?php echo date("Y.m.d"); ?> </div>
            </div>
            <div class = "alkalmazott-adatai">
                <div class = "adat_fejlec"> Szabadság/Home Office adatok </div>
                <div class = "adat"> Éves összes: (<?php echo $ev; ?>): <?php echo $eves_szabadsag['szabadnapok_szama']; ?> </div>
                <div class = "adat"> Felhasznált: (<?php echo $ev; ?>): <?php echo $felhasznalt_szabadsag; ?> </div>
                <div class = "adat"> Felhasználható: (<?php echo $ev; ?>): <?php echo $felhasznalhato_szabadsag; ?> </div>
                <div class = "adat"> Igénybe vett home office: (<?php echo $ev; ?>): <?php echo $igenybevett_homeoffice; ?> </div>
            </div>

            <form action = "igenyles.php" method = "POST">                                    
            <input type="hidden" name="szuletesi_nev" value="<?php echo htmlspecialchars($row['szuletesi_nev']); ?>">
            <input type="hidden" name="eves_szabadsag" value=<?php echo $eves_szabadsag['szabadnapok_szama']; ?>>
            <input type="hidden" name="felhasznalt_szabadsag" value=<?php echo $felhasznalt_szabadsag; ?>>
            <input type="hidden" name="felhasznalhato_szabadsag" value=<?php echo $felhasznalhato_szabadsag; ?>>
            <input type="hidden" name="igenybe_vett_home_office" value=<?php echo $igenybevett_homeoffice; ?>>
            <input type="hidden" name="home_office_lehetoseg" value=<?php echo $home_office; ?>>
            
            <div class = "gomb-csoport">
            <button type='submit' name='igeny_tipus' value='szabadsag' class='honap'>Szabadság igénylés</button>
            <?php
                if ($home_office) {
                    echo "<button type='submit' name='igeny_tipus' value='home office' class='honap'>Home Office igénylés</button>";
                }
                if ($vezeto) {
                    echo "<button class='honap' formaction='jovahagyas.php'>Jóváhagyások</button>";
                }
            ?> 
            </div>
            </form>
            <form action = "jelszo_modositas.php" method = "POST">
                <button type = submit class = "honap"> Jelszó módosítása </button>
            </form>

            <form action = "kilepes.php" method = "POST">
                <button type = submit class = "honap"> Kilépés </button>
            </form>
        </div>
   

        <form method = "POST">
        <div class = "honapok">
            <?php
                foreach ($honapok as $key => $ho) {
                    if ($ho === date_format($lekert_datum, "m")) {
                        echo "<button type=submit class='akt_honap' name = honap-ertek value =" . $ho . ">" . $key ."</button>";
                    } else {
                        echo "<button type=submit class='honap' name = honap-ertek value =" . $ho . ">" . $key ."</button>";
                    }
                }
            ?>
        </div>
        </form>
        

        <table class="lista">
            <caption>Jelenléti ív </caption>
            <thead>
                <tr>
                    <th>dátum</th>
                    <th>nap típusa</th>
                    <th>munkaidő kezdete</th>
                    <th>munkaidő vége</th>
                    <th>típus</th>
                    <th>jóváhagyva</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($naptar)): ?>
                    <?php if ($uj_adat || $modositas): ?> <!-- $uj_adat vagy $modositas === true -->
                        <?php foreach ($naptar as $nap): ?>
                            <?php
                                if ($nap['2'] == 'Pihenőnap') { $sor_osztaly = 'sor-piheno'; }
                                elseif ($nap['2'] == 'Ünnepnap') { $sor_osztaly = 'sor-unnep'; }
                                elseif ($nap['2'] == 'Munkanap') { $sor_osztaly = 'sor-munka'; }
                                else $sor_osztaly = 'sor-hiba';
                            ?>
                            <form action="" method=POST id="munkaido" onsubmit="return ellenoriz();">
                            <tr class="<?= $sor_osztaly ?>">
                                <td style="display:none"> <input type="hidden" name="eves_munkaido_naptar_azonosito" value=<?php echo htmlspecialchars((string)$nap['0']);?>> </td> 
                                <td style="display:none"> <input type="hidden" name="alk_munk_nyilv_az" value=<?php echo htmlspecialchars((string)$nap['7'] ?? '');?>> </td>
                                <td><?php echo htmlspecialchars((string)$nap['1'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars((string)$nap['2'] ?? ''); ?></td>
                                <td>
                                    <?php 
                                        if (($_POST['eves_munkaido_naptar_azonosito'] == htmlspecialchars((string)$nap['0']))) {
                                            $nyers_ido = $nap['3'] ?? '';
                                            $aktualis_ertek = !empty($nyers_ido) ? date('H:i', strtotime($nyers_ido)) : '--:--';
                                            $aktualis_ertek = htmlspecialchars($aktualis_ertek);
                                            echo '<input type="time" name="munk_kezd" id="munk_kezd" value=' . $aktualis_ertek . '>';
                                        } elseif (($nap['6']) != '') {
                                            $nyers_ido = $nap['3'] ?? '';
                                            $aktualis_ertek = !empty($nyers_ido) ? date('H:i', strtotime($nyers_ido)) : '--:--';
                                            $aktualis_ertek = htmlspecialchars($aktualis_ertek);
                                            echo $aktualis_ertek;
                                        } 
                                    ?> 
                                </td>
                                <td>
                                    <?php 
                                        if (($_POST['eves_munkaido_naptar_azonosito'] == htmlspecialchars((string)$nap['0']))) {
                                            $nyers_ido = $nap['4'] ?? '';
                                            $aktualis_ertek = !empty($nyers_ido) ? date('H:i', strtotime($nyers_ido)) : '--:--';
                                            $aktualis_ertek = htmlspecialchars($aktualis_ertek);
                                            echo '<input type="time" name="munk_vege" id="munk_vege" value=' . $aktualis_ertek . '>';
                                        } elseif (($nap['6']) != '') {
                                            $nyers_ido = $nap['4'] ?? '';
                                            $aktualis_ertek = !empty($nyers_ido) ? date('H:i', strtotime($nyers_ido)) : '--:--';
                                            $aktualis_ertek = htmlspecialchars($aktualis_ertek);
                                            echo $aktualis_ertek;
                                        } 
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                        if (($_POST['eves_munkaido_naptar_azonosito'] == htmlspecialchars((string)$nap['0']))) {
                                            $aktualis_ertek = htmlspecialchars((string)$nap['6'] ?? '');
                                            echo '<select name="tipus" id="tipus">';
                                            echo '<option value="ledolgozott nap" ' . ($aktualis_ertek == 'ledolgozott nap' ? 'selected' : '') . '>ledolgozott nap</option>';
                                            echo '<option value="szabadság" ' . ($aktualis_ertek == 'szabadság' ? 'selected' : '') . '>szabadság</option>';
                                            echo '<option value="betegszabadság" ' . ($aktualis_ertek == 'betegszabadság' ? 'selected' : '') . '>betegszabadság</option>';
                                            echo '<option value="home office" ' . ($aktualis_ertek == 'home office' ? 'selected' : '') . '>home office</option>';
                                            echo '</select>';
                                        } else echo htmlspecialchars((string)$nap['6'] ?? '');
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars((string)$nap['5'] ?? ''); ?></td>
                                <td>
                                    <?php 
                                        if (($nap[1] <= date("Y-m-d")) && ($nap[1] >= $belepes_datuma) && (($kilepes_datuma == "") || ($nap[1] <= $kilepes_datuma)) && ($_POST['eves_munkaido_naptar_azonosito'] == htmlspecialchars((string)$nap['0']))) {
                                            if ($uj_adat) {echo '<button class="edit-btn" type="submit" name="gomb" value="uj_mentes">Mentés</button>';}
                                            elseif ($modositas) {echo '<button class="edit-btn" type="submit" name="gomb" value="modositas_mentes"">Mentés</button>';}
                                        }
                                    ?>
                                </td>
                                <?php 
                                    if (($_POST['eves_munkaido_naptar_azonosito'] == htmlspecialchars((string)$nap['0']))) 
                                        { echo '<td> <div id="hibaUzenet" class="error"> </div></td>';} 
                                    else 
                                        {echo '<td></td>';}
                                ?> 
                            </tr>
                            </form>
                        <?php endforeach; ?>
                    <?php else: ?>  <!-- $uj_adat vagy $modositas === false -->
                         <?php foreach ($naptar as $nap): ?>
                            <?php
                                if ($nap['2'] == 'Pihenőnap') { $sor_osztaly = 'sor-piheno'; }
                                elseif ($nap['2'] == 'Ünnepnap') { $sor_osztaly = 'sor-unnep'; }
                                elseif ($nap['2'] == 'Munkanap') { $sor_osztaly = 'sor-munka'; }
                                else $sor_osztaly = 'sor-hiba';
                            ?>
                            <form action="" method=POST id="munkaido">
                            <tr class="<?= $sor_osztaly ?>">
                                <td style="display:none"> <input type="hidden" name="eves_munkaido_naptar_azonosito" value=<?php echo htmlspecialchars((string)$nap['0']);?>> </td> 
                                <td style="display:none"> <input type="hidden" name="alk_munk_nyilv_az" value=<?php echo htmlspecialchars((string)$nap['7'] ?? '');?>> </td>
                                <td><?php echo htmlspecialchars((string)$nap['1'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars((string)$nap['2'] ?? ''); ?></td>
                                <td>
                                    <?php 
                                        if (($nap['6']) != '') {
                                            $nyers_ido = $nap['3'] ?? '';
                                            $aktualis_ertek = !empty($nyers_ido) ? date('H:i', strtotime($nyers_ido)) : '--:--';
                                            $aktualis_ertek = htmlspecialchars($aktualis_ertek);
                                            echo $aktualis_ertek;
                                        } 
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                        if (($nap['6']) != '') {
                                            $nyers_ido = $nap['4'] ?? '';
                                            $aktualis_ertek = !empty($nyers_ido) ? date('H:i', strtotime($nyers_ido)) : '--:--';
                                            $aktualis_ertek = htmlspecialchars($aktualis_ertek);
                                            echo $aktualis_ertek;
                                        } 
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars((string)$nap['6'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars((string)$nap['5'] ?? ''); ?></td>
                                <td>
                                    <?php 
                                        if (($nap[1] <= date("Y-m-d")) && ($nap[1] >= $belepes_datuma) && (($kilepes_datuma == "") || ($nap[1] <= $kilepes_datuma))) {
                                            if (($nap['5']) == 'N') { echo '<button class="edit-btn" type="submit" name="gomb" value="modositas">Módosítás</button>'; }
                                            elseif (($nap['5']) == '') { echo '<button class="edit-btn" type="submit" name="gomb" value="uj">Új</button>'; }
                                        }
                                    ?>
                                </td>
                                <td> </td>
                            </tr>
                            </form>
                        <?php endforeach; ?>                       
                    <?php endif; ?> 
                <?php else: ?>
                    <tr>
                        <td colspan="7">Nem találhatók adatok az adatbázisban.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    
    </body>
</html>