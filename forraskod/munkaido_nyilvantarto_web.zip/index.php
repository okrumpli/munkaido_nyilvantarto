<?php
    session_start();
    session_destroy();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belépés</title>
    <link href="tools/alap.css" type="text/css" rel="stylesheet">
</head>
<body>

<div class="login-container">
    <h2>Belépés</h2>
    <form id="loginForm" action="bejelentkezes.php" method="POST" onsubmit="return ellenoriz();">
        <div class="form-group">
            <label for="nev">Email/Adóazonosító jel:</label>
            <input type="text" id="bejelentkezesi_azonosito" name="bejelentkezesi_azonosito">
        </div>
        <div class="form-group">
            <label for="jelszo">Jelszó:</label>
            <input type="password" id="jelszo" name="jelszo">
        </div>
        <div id="hibaUzenet" class="error"></div>
        <button type="submit">Belépés</button>
    </form>
</div>

<script>
    function ellenoriz() {
        const nev = document.getElementById('bejelentkezesi_azonosito').value.trim();
        const jelszo = document.getElementById('jelszo').value.trim();
        const hibaUzenet = document.getElementById('hibaUzenet');

        if (bejelentkezesi_azonosito === '' || jelszo === '') {
            hibaUzenet.textContent = 'Kérlek, töltsd ki mindkét mezőt!';
            return false;
        }

        hibaUzenet.textContent = '';
        return true;
    }
</script>
    
</body>
</html>