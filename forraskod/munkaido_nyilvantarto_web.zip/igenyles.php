<?php
    require_once "tools/db_params.php";
    
    session_start();

    if (!isset($_SESSION["alkalmazott_azonosito"]))
    {
        header("location: index.php");
        exit;
    }

    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8");

    if ($conn->connect_error) {
        die(json_encode(["error" => "Kapcsolódási hiba"]));
    }

    if (isset($_POST['home_office_lehetoseg'])) {
        $homeoffice_lehetoseg = $_POST['home_office_lehetoseg'];
    }       

    if (isset($_POST['igeny_tipus'])) {
        $tipus = $_POST['igeny_tipus'];
        if (($tipus === "home office") && ($homeoffice_lehetoseg === false)) {
            header("location: fooldal.php");
            exit;
        }
    }
    
    if (isset($_POST['szuletesi_nev'])) {
        $nev = $_POST['szuletesi_nev'];
    }       
            
    if (isset($_POST['eves_szabadsag'])) {
        $szabadsag = $_POST['eves_szabadsag'];
    }       

    if (isset($_POST['felhasznalt_szabadsag'])) {
        $felhasznalt = $_POST['felhasznalt_szabadsag'];
    }       
    
    if (isset($_POST['felhasznalhato_szabadsag'])) {
        $felhasznalhato = $_POST['felhasznalhato_szabadsag'];
    }
     
    if (isset($_POST['igenybe_vett_home_office'])) {
        $homeoffice = $_POST['igenybe_vett_home_office'];
    }
    
    $ev = date("Y");
    $elso_datum = date_format(date_create(date("Y") . "-01-01"),"Y-m-d");
    $utolso_datum = date_format(date_create(date("Y") . "-12-31"),"Y-m-d");

    $sql = "select * from eves_munkaido_naptar WHERE datum between ? and ?;";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $elso_datum,$utolso_datum);
    $stmt->execute();
    $result = $stmt->get_result();
    $naptar = $result->fetch_all(MYSQLI_ASSOC);
    $datum_oszlop = array_column($naptar, 'datum');


    $honapok_nevei = [
        1 => "Január", 2 => "Február", 3 => "Március", 4 => "Április",
        5 => "Május", 6 => "Június", 7 => "Július", 8 => "Augusztus",
        9 => "Szeptember", 10 => "Október", 11 => "November", 12 => "December"
    ];
    
    $nap_fejlecek = ["H", "K", "Sze", "Cs", "P", "Szo", "V"];
?>

<!DOCTYPE html>
<html lang="hu">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szabadság/Home office igénylés</title>
    <link href="tools/nyilvantarto.css" type="text/css" rel="stylesheet">

    <head>

    </head>
    <body>
        <div class = "honapok">
            <button class = "honap" onclick="document.location='fooldal.php'" > vissza a főoldalra </button>
        </div>
        <h1> 
            <?php 
                if ($tipus === "szabadsag") { echo "Szabadság igénylés"; }
                else { echo "Home office igénylés"; }
            ?> 
        </h1>
        <div class = "fejlec">
            <div class = "alkalmazott-adatai">
                <div class = "adat_fejlec"> Személyi adatok </div>
                <div class = "adat"> Név: <?php echo $nev; ?> </div>
                <div class = "adat"> Mai dátum: <?php echo date("Y.m.d"); ?> </div>
            </div>
            <div class = "alkalmazott-adatai">
                <div class = "adat_fejlec"> Szabadság/Home Office adatok </div>
                <div class = "adat"> Éves összes: (<?php echo $ev; ?>): <?php echo $szabadsag; ?> </div>
                <div class = "adat"> Felhasznált: (<?php echo $ev; ?>): <?php echo $felhasznalt; ?> </div>
                <div class = "adat"> Felhasználható: (<?php echo $ev; ?>): <?php echo $felhasznalhato; ?> </div>
                <div class = "adat"> Igénybe vett home office: (<?php echo $ev; ?>): <?php echo $homeoffice; ?> </div>
            </div>
        </div>

        <h1>Naptár - <?php echo $ev; ?></h1>

        <form action="igenyles_leadas.php" method="POST">
        <div class="ev-kontener">
            <?php
                for ($honap = 1; $honap <= 12; $honap++) {
            ?>
            <div class="honap-kartya">
                <div class="honap-nev"><?php echo $honapok_nevei[$honap]; ?></div>
                
                <div class="napok-racs">
                    <?php foreach ($nap_fejlecek as $fejlec): ?>
                        <div class="fejlec-nap"><?php echo $fejlec; ?></div>
                    <?php endforeach; ?>

                    <?php
                    $elso_nap_datuma = "$ev-" . str_pad($honap, 2, "0", STR_PAD_LEFT) . "-01";
                    
                    $elso_nap_hete = date('N', strtotime($elso_nap_datuma));
                    
                    $napok_szama = date('t', strtotime($elso_nap_datuma));

                    for ($i = 1; $i < $elso_nap_hete; $i++) {
                        echo '<div class="ures-nap"></div>';
                    }

                    for ($nap = 1; $nap <= $napok_szama; $nap++) {
                        $inaktiv = false;
                        $aktualis_datum = "$ev-" . str_pad($honap, 2, "0", STR_PAD_LEFT) . "-" . str_pad($nap, 2, "0", STR_PAD_LEFT);
                        
                        if ($aktualis_datum < date("Y-m-d")) {$inaktiv = true; $naptar_osztaly = 'naptar-nap';}
                        elseif ($naptar[array_search($aktualis_datum,$datum_oszlop)]['nap_tipusa'] === 'Munkanap') {$naptar_osztaly = 'naptar-nap-munka';}
                        elseif ($naptar[array_search($aktualis_datum,$datum_oszlop)]['nap_tipusa'] === "Pihenőnap") {$naptar_osztaly = 'naptar-nap-piheno';}
                        elseif ($naptar[array_search($aktualis_datum,$datum_oszlop)]['nap_tipusa'] === "Ünnepnap") {$naptar_osztaly = 'naptar-nap-unnep';}
                        else {$naptar_osztaly = 'naptar-nap';};

                        ?>
                        <div class=<?php echo $naptar_osztaly; ?>>
                            <input type="checkbox" name="napok[]" value="<?php echo $aktualis_datum; ?>" <?php echo ($inaktiv) ? 'disabled' : ""; ?>>
                            <span><?php echo $nap; ?></span>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
            <?php
                }
            ?>
        </div>

        <div class="gomb-kontener">
            <input type="hidden" name="igeny_tipus" value="<?php echo $tipus; ?>">
            <button type="submit" class="mentes-gomb">Igénylés leadása</button>
        </div>
        </form>

    </body>
</html>