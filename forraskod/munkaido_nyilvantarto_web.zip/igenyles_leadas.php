<?php
    require_once "tools/db_params.php";
    
    session_start();

    if (!isset($_SESSION["alkalmazott_azonosito"]))
    {
        header("location: index.php");
        exit;
    }

    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8");

    if ($conn->connect_error) {
        die(json_encode(["error" => "Kapcsolódási hiba"]));
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $kivalasztott_napok = isset($_POST['napok']) ? $_POST['napok'] : [];

        if (isset($_POST['igeny_tipus'])) {
           $tipus = $_POST['igeny_tipus'];
        }
    
        try {
            mysqli_autocommit($conn, FALSE);
            if (!empty($kivalasztott_napok)) {
                $sql = "call uj_igenyles_felvitele(?,?,?)";
                $stmt = $conn->prepare($sql);

                foreach ($kivallasztott_napok as $datum) {
                    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $datum)) {
                        $stmt->bind_param("iss", $_SESSION["alkalmazott_azonosito"], $datum, $tipus);
                        $stmt->execute();
                    }
                }
            }

            $conn->commit();

            header("Location: fooldal.php?status=siker");
            exit;

        } catch (Exception $e) {
            $conn->rollBack();
            die("Hiba történt a mentés során: " . $e->getMessage());
        }
        } else {
        header("Location: fooldal.php");
    exit;
    }
?>