<?php
    require_once "tools/db_params.php";

    session_start();
    
    if (!isset($_SESSION["alkalmazott_azonosito"]))
        {
            header("location: index.php");
            exit;
        }

    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8");

    if ($conn->connect_error) {
        die(json_encode(["error" => "Kapcsolódási hiba"]));
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['regi_jelszo']) && isset($_POST['uj_jelszo'])) {
            change_password($conn);
        }
    }

    function change_password($conn)
    {
        $regi = $_POST['regi_jelszo'];
        $uj = $_POST['uj_jelszo'];
        $alkalmazott_id = $_SESSION["alkalmazott_azonosito"];
        $sql = "call alkalmazott_jelszo_modositasa(?,?,?);";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $alkalmazott_id,$regi,$uj);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            echo "<script>alert('Sikeres jelszómódosítás!');</script>";
        } else {
            echo "<script>alert('A módosítás sikertelen! (Hibás régi jelszó vagy nem történt változás)');</script>";
        }
        $stmt->close();
    }
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jelszó módosítása</title>
    <link href="tools/alap.css" type="text/css" rel="stylesheet">

    <script>
        function ellenoriz() {
            const regi_jelszo = document.getElementById('regi_jelszo').value.trim();
            const uj_jelszo = document.getElementById('uj_jelszo').value.trim();
            const uj_jelszo2 = document.getElementById('uj_jelszo2').value.trim();
            const hibaUzenet = document.getElementById('hibaUzenet');

            if (regi_jelszo === '' || uj_jelszo === '' || uj_jelszo2 === '') {
                hibaUzenet.textContent = 'Kérlek, töltsd ki mindkét mezőt!';
                return false;
            }

            if (uj_jelszo != uj_jelszo2) {
                hibaUzenet.textContent = 'Nem sikerült az új jelszót kétszer beírni!';
                return false;
            }

            if (regi_jelszo === uj_jelszo) {
                hibaUzenet.textContent = 'A régi és az új jelszó nem egyezhet meg!';
                return false;
            }

            hibaUzenet.textContent = '';
            return true;
        }
    </script>

</head>
<body>

    <div class = "honapok">
        <button class = "honap" onclick="document.location='fooldal.php'" > vissza a főoldalra </button>
    </div>

    <div class="login-container">
        <h2>Jelszó módosítása</h2>
        <form id="loginForm" action="" method="POST" onsubmit="return ellenoriz();">
            <div class="form-group">
                <label for="nev">Régi jelszó:</label>
                <input type="password" id="regi_jelszo" name="regi_jelszo">
            </div>
            <div class="form-group">
                <label for="nev">Új jelszó:</label>
                <input type="password" id="uj_jelszo" name="uj_jelszo">
            </div>
            <div class="form-group">
                <label for="jelszo">Új jelszó ismét:</label>
                <input type="password" id="uj_jelszo2" name="uj_jelszo2">
            </div>
            <div id="hibaUzenet" class="error"></div>
            <button type="submit">Mentés</button>
        </form>
    </div>    
</body>
</html>