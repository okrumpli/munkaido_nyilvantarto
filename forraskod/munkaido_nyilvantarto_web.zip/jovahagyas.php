<?php
    require_once "tools/db_params.php";
    
    session_start();

    if (!isset($_SESSION["alkalmazott_azonosito"]))
    {
        header("location: index.php");
        exit;
    }

    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8");

    if ($conn->connect_error) {
        die(json_encode(["error" => "Kapcsolódási hiba"]));
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if ((isset($_POST['igenyles_azonosito'])) && (isset($_POST['dontes']))) {
            igenyles_kezelese($conn);
        }
        if ((isset($_POST['munkaido_azonosito'])) && (isset($_POST['jovahagy']))) {
            nap_jovahagyasa($conn);
        }
    }

    $sql = "call jovahagyando_igenylesek_listaja(?);";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION["alkalmazott_azonosito"]);
    $stmt->execute();
    $result = $stmt->get_result();
    $lista = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $sql = "call jovahagyando_munkaido_listaja(?);";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION["alkalmazott_azonosito"]);
    $stmt->execute();
    $result = $stmt->get_result();
    $lista2 = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    function igenyles_kezelese($conn)
    {
        $dontes = $_POST['dontes'];
        $igenyles_id = $_POST["igenyles_azonosito"];
        $sql = "call igenyles_kezelese(?,?);";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $igenyles_id,$dontes);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            echo "<script>console.log('Sikeres módosítás!');</script>";
            unset($_POST['dontes']);
            unset($_POST['igenyles_azonosito']);
        } else {
            echo "<script>console.log('A módosítás sikertelen!');</script>";
        }
        $stmt->close();
    }
    
    function nap_jovahagyasa($conn)
    {
        $jovahagy = $_POST['jovahagy'];
        $munkanap_id = $_POST["munkaido_azonosito"];
        $sql = "call alkalmazotti_munkaido_jovahagyas(?,?);";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $munkanap_id,$jovahagy);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            echo "<script>console.log('Sikeres módosítás!');</script>";
            unset($_POST['jovahagy']);
            unset($_POST['munkanap_azonosito']);
        } else {
            echo "<script>console.log('A módosítás sikertelen!');</script>";
        }
        $stmt->close();
    }
?>

<!DOCTYPE html>
<html lang="hu">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szabadság/Home office jóváhagyás</title>
    <link href="tools/nyilvantarto.css" type="text/css" rel="stylesheet">

    <script>

    </script>

    </head>
    <body>
        <div class = "honapok">
            <button class = "honap" onclick="document.location='fooldal.php'" > vissza a főoldalra </button>
        </div>
        
        <table class="lista">
            <caption>Jóváhagyásra váró igénylések</caption>
            <thead>
                <tr>
                    <th>születési név</th>
                    <th>dátum</th>
                    <th>típus</th>
                    <th>jóváhagyva</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($lista)): ?>
                    <?php foreach ($lista as $sor): ?>
                        <?php 
                            if ($sor['tipus'] == "szabadság") { $sor_osztaly = 'sor-szabadsag'; }
                            elseif ($sor['tipus'] == "home office") { $sor_osztaly = 'sor-homeoffice'; } 
                        ?>

                        <form action="" method=POST id="igenyles">
                        <tr class="<?= $sor_osztaly ?>">
                            <td style="display:none"> <input type="hidden" name="igenyles_azonosito" value=<?php echo htmlspecialchars((string)$sor['igenyles_azonosito']);?>> </td> 
                            <td><?php echo htmlspecialchars((string)$sor['szuletesi_nev'] ?? ' '); ?></td>
                            <td><?php echo htmlspecialchars((string)$sor['datum'] ?? ' '); ?></td>
                            <td><?php echo htmlspecialchars((string)$sor['tipus'] ?? ' '); ?></td>
                            <td><?php echo htmlspecialchars((string)$sor['jovahagyva'] ?? ' '); ?></td>
                            <td>
                                <?php
                                    { echo '<button class="edit-btn" type="submit" name="dontes" value="I">Jóváhagy</button>'; }
                                ?> 
                            </td>
                            <td>
                                <?php 
                                    { echo '<button class="edit-btn" type="submit" name="dontes" value="E">Elutasit</button>'; }
                                ?>
                            </td>
                        </tr>
                        </form>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">Nem találhatók adatok az adatbázisban.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <table class="lista">
            <caption>Jóváhagyásra váró jelenléti adatok</caption>
            <thead>
                <tr>
                    <th>születési név</th>
                    <th>dátum</th>
                    <th>munkaidő kezdete</th>
                    <th>munkaidő vége</th>
                    <th>tipus</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($lista2)): ?>
                    <?php foreach ($lista2 as $sor): ?>
                        <?php 
                            if ($sor['statusz'] == "szabadság") { $sor_osztaly = 'sor-szabadsag'; }
                            elseif ($sor['statusz'] == "home office") { $sor_osztaly = 'sor-homeoffice'; } 
                            elseif ($sor['statusz'] == "ledolgozott nap") { $sor_osztaly = 'sor-ledolgozott-nap'; } 
                            elseif ($sor['statusz'] == "betegszabadság") { $sor_osztaly = 'sor-betegszabadsag'; }                             
                        ?>
                        <form action="" method=POST id="munkaido_jovahagyas">
                        <tr class="<?= $sor_osztaly ?>" >
                            <td style="display:none"> <input type="hidden" name="munkaido_azonosito" value=<?php echo htmlspecialchars((string)$sor['alkalmazotti_munkaido_nyilvantartas_azonosito']);?>> </td> 
                            <td><?php echo htmlspecialchars((string)$sor['szuletesi_nev'] ?? ' '); ?></td>
                            <td><?php echo htmlspecialchars((string)$sor['datum'] ?? ' '); ?></td>
                            <td><?php echo htmlspecialchars((string)$sor['munkaido_kezdete'] ?? ' '); ?></td>
                            <td><?php echo htmlspecialchars((string)$sor['munkaido_vege'] ?? ' '); ?></td>
                            <td><?php echo htmlspecialchars((string)$sor['statusz'] ?? ' '); ?></td>                            
                            <td>
                                <?php 
                                    { echo '<button class="edit-btn" type="submit" name="jovahagy" value="I">Jóváhagy</button>'; }
                                ?>
                            </td>
                        </tr>
                    </form>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">Nem találhatók adatok az adatbázisban.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </body>
</html>