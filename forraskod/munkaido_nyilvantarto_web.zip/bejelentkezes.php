<?php
    require_once "tools/db_params.php";

    session_start();
    $_SESSION["alkalmazott_azonosito"] = "";
    $_SESSION["hiba"] = "";

    $bejelentkezesi_azonosito = $_POST["bejelentkezesi_azonosito"] ?? "";
    $jelszo = $_POST["jelszo"] ?? "";
    $bejelentkezesi_azonosito2 = $bejelentkezesi_azonosito;

    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn->set_charset("utf8");

    if ($conn->connect_error) {
        die(json_encode(["error" => "Kapcsolódási hiba"]));
    }

    $sql = "select * from alkalmazott WHERE (adoazonosito_jel = ? OR email = ?) AND jelszo = SHA2(?,256) AND kilepes_datuma IS NULL;";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $bejelentkezesi_azonosito, $bejelentkezesi_azonosito2, $jelszo);

    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($result->num_rows === 0) {
        $_SESSION["hiba"] = "Hibás bejelentkezés!";
        header("location: hibas_belepes.php");
    } else if ($result->num_rows === 1) {

        $_SESSION["alkalmazott_azonosito"] = $row["alkalmazott_azonosito"];
        $_SESSION["hiba"] = "Sikeres bejelentkezés!<br>alkalmazott azonosító: ";
        header("location: fooldal.php");

    } else if ($result->num_rows > 1)  {
        $_SESSION["hiba"] = "Nem egyértelműen azonosítható felhasználó!<br>Kérem forduljon a rendszergazdához!";
        header("location: hibas_belepes.php");
    }

    $stmt->close();
    $conn->close();
?>