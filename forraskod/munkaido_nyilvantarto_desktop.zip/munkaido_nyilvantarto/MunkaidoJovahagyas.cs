﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace munkaido_nyilvantarto
{
    public partial class frm_MunkaidoJovahagyas : Form
    {
        int munkaido_azonosito;
        public frm_MunkaidoJovahagyas()
        {
            InitializeComponent();
        }

        private void Jovahagyas_Shown(object sender, EventArgs e)
        {
            frissit();
        }

        private void dgv_Munkaidok_SelectionChanged(object sender, EventArgs e)
        {
            if (dgv_Munkaidok.SelectedRows.Count > 0)
            {
                munkaido_azonosito = Convert.ToInt32(dgv_Munkaidok.SelectedRows[0].Cells["alkalmazotti_munkaido_nyilvantartas_azonosito"].Value);
            }

        }

        private void btn_Bezar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Jovahagyas_Click(object sender, EventArgs e)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "alkalmazotti_munkaido_jovahagyas";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("p_alk_munk_nyilv_az", munkaido_azonosito);
                cmd.Parameters.AddWithValue("p_dontes", "I");
                cmd.ExecuteNonQuery();
            }
            frissit();
        }

        private void frissit()
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                var dt = new DataTable();
                String sql = "call osszes_jovahagyando_munkaido();";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                var da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dgv_Munkaidok.DataSource = dt;
                dgv_Munkaidok.Columns["alkalmazott_azonosito"].Visible = false;
                dgv_Munkaidok.Columns["alkalmazotti_munkaido_nyilvantartas_azonosito"].Visible = false;
                dgv_Munkaidok.Columns["eves_munkaido_naptar_azonosito"].Visible = false;
                dgv_Munkaidok.Columns["szuletesi_nev"].HeaderText = "Születési név";
                dgv_Munkaidok.Columns["datum"].HeaderText = "Dátum";
                dgv_Munkaidok.Columns["munkaido_kezdete"].HeaderText = "Munkaidő kezdete";
                dgv_Munkaidok.Columns["munkaido_vege"].HeaderText = "Munkaidő vége";
                dgv_Munkaidok.Columns["jovahagyva"].HeaderText = "Jóváhagyva";
                dgv_Munkaidok.Columns["statusz"].HeaderText = "Típus";
            }
        }
    }
}
