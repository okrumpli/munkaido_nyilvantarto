using MySqlConnector;
using System.Security.Cryptography.X509Certificates;

namespace munkaido_nyilvantarto
{
    public partial class frm_Bejelentkezes : Form
    {

        public frm_Bejelentkezes()
        {
            InitializeComponent();
        }

        private void btn_Kilepes_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Bejelentkezes_Click(object sender, EventArgs e)

        {
            if (lb_BejelentkezesiHiba.Visible)
                lb_BejelentkezesiHiba.Visible = false;

            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                try
                {
                    mc_mysqlcon.Open();
//                    String sql = "select * from alkalmazott WHERE (adoazonosito_jel = '" + tb_Bejelentkezes.Text + "' OR email = '" + tb_Bejelentkezes.Text + "') AND jelszo = SHA2('" + tb_Jelszo.Text + "',256) AND adminisztrator = 'I' AND kilepes_datuma IS NULL;";  //Fut�s k�zben az els� mez�be ezt be�rva, jelsz� n�lk�l is be lehetne jelentkezni: ') OR 1=1 LIMIT 1;  --
                    String sql = "select * from alkalmazott WHERE (adoazonosito_jel = @bejelentkezesi_azonosito OR email = @bejelentkezesi_azonosito) AND jelszo = SHA2(@jelszo,256) AND adminisztrator = 'I' AND kilepes_datuma IS NULL;";

                    var cmd = new MySqlCommand(sql, mc_mysqlcon);
                    cmd.Parameters.AddWithValue("@bejelentkezesi_azonosito", tb_Bejelentkezes.Text);
                    cmd.Parameters.AddWithValue("@jelszo", tb_Jelszo.Text);
                    using (var reader = cmd.ExecuteReader())
                    {
                        int sorszamlalo = 0;
                        while (reader.Read())
                            sorszamlalo++;

                        if (sorszamlalo == 0)
                        {
                            lb_BejelentkezesiHiba.Text = "Hib�s bejelentkez�s!";
                            lb_BejelentkezesiHiba.Visible = true;
                        }
                        else if (sorszamlalo == 1)
                        {
                            if (lb_BejelentkezesiHiba.Visible)
                                lb_BejelentkezesiHiba.Visible = false;
                            tb_Bejelentkezes.Text = "";
                            tb_Jelszo.Text = "";
                            frm_Foablak foablak = new frm_Foablak();
                            this.Hide();                    // Csak elrejti a bejelentkez�si ablakot
                            foablak.ShowDialog();
                            this.Close();                   // Itt fejez�dik be az eg�sz program fut�sa
                        }
                        else if (sorszamlalo > 1)           // Ilyen elvileg nem t�rt�nhet meg!!!
                        {
                            lb_BejelentkezesiHiba.Text = "Nem egy�rtelm�en azonos�that� felhaszn�l�!\nK�rem forduljon a rendszergazd�hoz!";
                            lb_BejelentkezesiHiba.Visible = true;
                        }

                    }

                }
                catch (MySqlConnector.MySqlException ex)
                {
                    lb_BejelentkezesiHiba.Text = "Adatb�ziskapcsolati hiba!\nK�rem forduljon a rendszergazd�hoz!";
                    lb_BejelentkezesiHiba.Visible = true;
                    tb_Bejelentkezes.Text = "";
                    tb_Bejelentkezes.Enabled = false;
                    tb_Jelszo.Text = "";
                    tb_Jelszo.Enabled = false;
                }
            }
        }

        private void tb_Jelszo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btn_Bejelentkezes_Click(this, new EventArgs());
            }
            if (e.KeyCode == Keys.Escape)
            {
                btn_Kilepes_Click(this, new EventArgs());
            }
        }
    }
}
