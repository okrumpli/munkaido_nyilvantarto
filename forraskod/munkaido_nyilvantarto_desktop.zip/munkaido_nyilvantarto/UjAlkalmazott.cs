﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace munkaido_nyilvantarto
{
    public partial class frm_UjAlkalmazott : Form
    {
        List<int> cb_AlkEngedelyezo_azonosito_lista;
        public frm_UjAlkalmazott()
        {
            InitializeComponent();
            cb_AlkEngedelyezo_azonosito_lista = new List<int>();
        }

        private void frm_UjAlkalmazott_Shown(object sender, EventArgs e)
        {
            dtp_AlkSzuletesiIdo.Text = DateTime.Now.AddYears(-18).ToString();
            cb_AlkVezeto.Text = "N";
            cb_AlkHomeOfficeLehetoseg.Text = "N";
            dtp_AlkMunkaviszonyKezdete.Text = DateTime.Now.ToString();
            cb_AlkMunkaidoKezdete.Text = "08:00";
            cb_AlkMunkaidoVege.Text = "16:30";
            cb_AlkEbedidoKezdete.Text = "12:00";
            cb_AlkEbedidoVege.Text = "12:30";
            cb_Adminisztrator.Text = "N";

            engedelyezolista_feltoltese();
        }

        private void engedelyezolista_feltoltese()
        {
            cb_AlkEngedelyezo.Items.Clear();
            cb_AlkEngedelyezo_azonosito_lista.Clear();

            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "SELECT * FROM alkalmazott WHERE vezeto = 'I' AND kilepes_datuma IS NULL;";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cb_AlkEngedelyezo.Items.Add(reader.GetString("szuletesi_nev") + " (" + reader.GetString("beosztas") + ")");
                        cb_AlkEngedelyezo_azonosito_lista.Add(reader.GetInt32("alkalmazott_azonosito"));
                    }
                }
            }
        }

        private void tb_AlkIranyitoszam_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btn_AlkalmazottAdatainakModositasaMegsem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_AlkalmazottAdatainakModositasaMentes_Click(object sender, EventArgs e)
        {
            if (kitoltes_ellenorzese())
            {
                using (var mc_mysqlcon = new MySqlConnection(Program.constr))
                {
                    mc_mysqlcon.Open();
                    String sql = "uj_alkalmazott_felvitele";
                    var cmd = new MySqlCommand(sql, mc_mysqlcon);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("p_szuletesi_nev", tb_AlkSzuletesiNev.Text);
                    cmd.Parameters.AddWithValue("p_szuletesi_hely", tb_AlkSzuletesiHely.Text);
                    cmd.Parameters.AddWithValue("p_szuletesi_ido", dtp_AlkSzuletesiIdo.Value.ToString(@"yyyy\-MM\-dd"));
                    cmd.Parameters.AddWithValue("p_anyja_neve", tb_AlkAnyjaNeve.Text);
                    cmd.Parameters.AddWithValue("p_beosztas", tb_AlkBeosztas.Text);
                    cmd.Parameters.AddWithValue("p_email", tb_AlkEmail.Text);
                    cmd.Parameters.AddWithValue("p_adoazonositojel", tb_AlkAdoazonositoJel.Text);
                    cmd.Parameters.AddWithValue("p_vezeto", cb_AlkVezeto.Text);
                    cmd.Parameters.AddWithValue("p_homeoffice", cb_AlkHomeOfficeLehetoseg.Text);
                    if (cb_AlkEngedelyezo.Text == "") cmd.Parameters.AddWithValue("p_engedelyezo", DBNull.Value);
                    else cmd.Parameters.AddWithValue("p_engedelyezo", cb_AlkEngedelyezo_azonosito_lista[cb_AlkEngedelyezo.SelectedIndex]);
                    cmd.Parameters.AddWithValue("p_belepes_datuma", dtp_AlkMunkaviszonyKezdete.Value.ToString(@"yyyy\-MM\-dd"));
                    if (!dtp_AlkMunkaviszonyVege.Checked) cmd.Parameters.AddWithValue("p_kilepes_datuma", DBNull.Value);
                    else cmd.Parameters.AddWithValue("p_kilepes_datuma", dtp_AlkMunkaviszonyVege.Value.ToString(@"yyyy\-MM\-dd"));
                    cmd.Parameters.AddWithValue("p_adminisztrator", cb_AlkVezeto.Text);

                    cmd.Parameters.Add("@utolsoInsertID", MySqlDbType.Int32);
                    cmd.Parameters["@utolsoInsertID"].Direction = ParameterDirection.ReturnValue;

                    int uj_alkalmazott_azonosito = int.Parse(cmd.ExecuteScalar().ToString());
                    
                    alkLakcimFelvitele(uj_alkalmazott_azonosito, tb_AlkTelepulesNeve.Text, tb_AlkCim.Text, tb_AlkIranyitoszam.Text);
                    alkMunkaidejeFelvitele(uj_alkalmazott_azonosito, cb_AlkMunkaidoKezdete.Text, cb_AlkMunkaidoVege.Text, cb_AlkEbedidoKezdete.Text, cb_AlkEbedidoVege.Text);

                    MessageBox.Show("Az alkalmazott sikeresen rögzítve!");
                    this.Close();
                }
            }
            else MessageBox.Show("Kérem ellenőrizze az adatokat!");
        }

        private void alkLakcimFelvitele(int ujalkaz, string alktelepulesneve, string alkcim, string alkiranyitoszam)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "uj_lakcim_felvitele";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", ujalkaz);
                cmd.Parameters.AddWithValue("p_telepules_neve", alktelepulesneve);
                cmd.Parameters.AddWithValue("p_cim", alkcim);
                cmd.Parameters.AddWithValue("p_iranyitoszam", alkiranyitoszam);
                cmd.ExecuteNonQuery();
            }
        }

        private void alkMunkaidejeFelvitele(int ujalkaz, string alkmunkaidokezdete, string alkmunkaidovege, string alkebedidokezdete, string alkebedidovege)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "alkalmazott_munkaidejenek_felvitele";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", ujalkaz);
                cmd.Parameters.AddWithValue("p_munkaido_kezdete", alkmunkaidokezdete);
                cmd.Parameters.AddWithValue("p_munkaido_vege", alkmunkaidovege);
                cmd.Parameters.AddWithValue("p_ebedido_kezdete", alkebedidokezdete);
                cmd.Parameters.AddWithValue("p_ebedido_vege", alkebedidovege);
                cmd.ExecuteNonQuery();
            }
        }

        private bool idoEllenorzes()
        {
            TimeOnly MunkaidoKezdete = TimeOnly.Parse(cb_AlkMunkaidoKezdete.Text);
            TimeOnly MunkaidoVege = TimeOnly.Parse(cb_AlkMunkaidoVege.Text);
            TimeOnly EbedidoKezdete = TimeOnly.Parse(cb_AlkEbedidoKezdete.Text);
            TimeOnly EbedidoVege = TimeOnly.Parse(cb_AlkEbedidoVege.Text);

            if (!((MunkaidoKezdete < EbedidoKezdete) &&
                (EbedidoKezdete < EbedidoVege) &&
                (EbedidoVege < MunkaidoVege))) return false;
            return true;
        }

        private bool kitoltes_ellenorzese()
        {
            if (tb_AlkSzuletesiNev.Text == "") return false;
            if (tb_AlkSzuletesiHely.Text == "") return false;
            if (dtp_AlkSzuletesiIdo.Value > DateTime.Now) return false;
            if (tb_AlkAnyjaNeve.Text == "") return false;
            if (tb_AlkTelepulesNeve.Text == "") return false;
            if (tb_AlkCim.Text == "") return false;
            if (tb_AlkIranyitoszam.Text == "") return false;
            if (tb_AlkBeosztas.Text == "") return false;
            if (tb_AlkEmail.Text == "") return false;
            if (tb_AlkAdoazonositoJel.Text == "") return false;
            if (cb_AlkVezeto.Text == "") return false;
            if (cb_AlkHomeOfficeLehetoseg.Text == "") return false;
            if (dtp_AlkMunkaviszonyKezdete.Value < dtp_AlkSzuletesiIdo.Value) return false;
            if (dtp_AlkMunkaviszonyVege.Checked && (dtp_AlkMunkaviszonyKezdete.Value > dtp_AlkMunkaviszonyVege.Value)) return false;
            if (!idoEllenorzes()) return false;
            if (cb_Adminisztrator.Text == "") return false;
            return true;
        }
    }
}
