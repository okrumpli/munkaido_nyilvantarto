﻿namespace munkaido_nyilvantarto
{
    partial class frm_MunkaidoJovahagyas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_Munkaidok = new DataGridView();
            btn_Bezar = new Button();
            btn_Jovahagyas = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_Munkaidok).BeginInit();
            SuspendLayout();
            // 
            // dgv_Munkaidok
            // 
            dgv_Munkaidok.AllowUserToAddRows = false;
            dgv_Munkaidok.AllowUserToDeleteRows = false;
            dgv_Munkaidok.AllowUserToResizeColumns = false;
            dgv_Munkaidok.AllowUserToResizeRows = false;
            dgv_Munkaidok.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_Munkaidok.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Munkaidok.Location = new Point(12, 12);
            dgv_Munkaidok.MultiSelect = false;
            dgv_Munkaidok.Name = "dgv_Munkaidok";
            dgv_Munkaidok.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv_Munkaidok.Size = new Size(1102, 434);
            dgv_Munkaidok.TabIndex = 1;
            dgv_Munkaidok.SelectionChanged += dgv_Munkaidok_SelectionChanged;
            // 
            // btn_Bezar
            // 
            btn_Bezar.Location = new Point(1037, 492);
            btn_Bezar.Name = "btn_Bezar";
            btn_Bezar.Size = new Size(75, 23);
            btn_Bezar.TabIndex = 2;
            btn_Bezar.Text = "Bezárás";
            btn_Bezar.UseVisualStyleBackColor = true;
            btn_Bezar.Click += btn_Bezar_Click;
            // 
            // btn_Jovahagyas
            // 
            btn_Jovahagyas.Location = new Point(25, 464);
            btn_Jovahagyas.Name = "btn_Jovahagyas";
            btn_Jovahagyas.Size = new Size(75, 23);
            btn_Jovahagyas.TabIndex = 3;
            btn_Jovahagyas.Text = "Jóváhagyás";
            btn_Jovahagyas.UseVisualStyleBackColor = true;
            btn_Jovahagyas.Click += btn_Jovahagyas_Click;
            // 
            // frm_MunkaidoJovahagyas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1124, 527);
            Controls.Add(btn_Jovahagyas);
            Controls.Add(btn_Bezar);
            Controls.Add(dgv_Munkaidok);
            Name = "frm_MunkaidoJovahagyas";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Munkaidő jóváhagyás";
            Shown += Jovahagyas_Shown;
            ((System.ComponentModel.ISupportInitialize)dgv_Munkaidok).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgv_Munkaidok;
        private Button btn_Bezar;
        private Button btn_Jovahagyas;
    }
}