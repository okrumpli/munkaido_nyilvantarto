﻿namespace munkaido_nyilvantarto
{
    partial class frm_Foablak
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_Alkalmazottak = new DataGridView();
            ms_Menusor = new MenuStrip();
            tsmi_Program = new ToolStripMenuItem();
            tsmi_KilepesAProgrambol = new ToolStripMenuItem();
            lb_beosztas = new Label();
            grpb_AlkalmazottAdatai = new GroupBox();
            btn_AlkalmazottAdatainakModositasaMegsem = new Button();
            btn_AlkalmazottAdatainakModositasaMentes = new Button();
            btn_AlkalmazottAdatainakModositasa = new Button();
            lb_Engedelyezo = new Label();
            lb_AlkEngedelyezo = new Label();
            lb_Adminisztrator = new Label();
            lb_AlkAdminisztrator = new Label();
            lb_HomeOfficeLehetoseg = new Label();
            lb_AlkHomeOfficeLehetoseg = new Label();
            grpb_Munkaviszony = new GroupBox();
            btn_MunkaviszonyModositasaMegsem = new Button();
            btn_MunkaviszonyModositasaMentes = new Button();
            btn_MunkaviszonyModositasa = new Button();
            lb_AlkMunkaviszonyVege = new Label();
            lb_MunkaviszonyVege = new Label();
            lb_AlkMunkaviszonyKezdete = new Label();
            lb_MunkaviszonyKezdete = new Label();
            dtp_AlkMunkaviszonyKezdete = new DateTimePicker();
            dtp_AlkMunkaviszonyVege = new DateTimePicker();
            lb_Vezeto = new Label();
            lb_AlkVezeto = new Label();
            grpb_Munkarend = new GroupBox();
            btn_MunkaidoModositasMegsem = new Button();
            btn_MunkaidoModositasMentes = new Button();
            btn_MunkaidoModositas = new Button();
            lb_AlkEbedszunetVege = new Label();
            lb_EbedszunetVege = new Label();
            lb_AlkEbedszunetKezdete = new Label();
            lb_EbedszunetKezdete = new Label();
            lb_AlkMunkaidoVege = new Label();
            lb_MunkaidoVege = new Label();
            lb_AlkMunkaidoKezdete = new Label();
            lb_MunkaidoKezdete = new Label();
            cb_AlkMunkaidoKezdete = new ComboBox();
            cb_AlkMunkaidoVege = new ComboBox();
            cb_AlkEbedidoKezdete = new ComboBox();
            cb_AlkEbedidoVege = new ComboBox();
            lb_AdoazonositoJel = new Label();
            lb_AlkAdoazonositoJel = new Label();
            lb_email = new Label();
            lb_AlkEmail = new Label();
            lb_AlkAnyjaNeve = new Label();
            lb_AnyjaNeve = new Label();
            grpb_AlkalmazottLakcim = new GroupBox();
            btn_LakcimModositasaMegsem = new Button();
            btn_LakcimModositasaMentes = new Button();
            btn_LakcimModositasa = new Button();
            lb_AlkIranyitoszam = new Label();
            lb_Iranyitoszam = new Label();
            lb_AlkCim = new Label();
            lb_Cim = new Label();
            lb_AlkTelepulesNeve = new Label();
            lb_TelepulesNeve = new Label();
            tb_AlkIranyitoszam = new TextBox();
            tb_AlkCim = new TextBox();
            tb_AlkTelepulesNeve = new TextBox();
            lb_AlkBeosztas = new Label();
            lb_AlkSzuletesiIdo = new Label();
            lb_SzuletesiIdo = new Label();
            lb_AlkSzuletesiHely = new Label();
            lb_SzuletesiHely = new Label();
            lb_AlkSzuletesiNev = new Label();
            lb_SzuletesiNev = new Label();
            dtp_AlkSzuletesiIdo = new DateTimePicker();
            tb_AlkAnyjaNeve = new TextBox();
            tb_AlkSzuletesiHely = new TextBox();
            tb_AlkSzuletesiNev = new TextBox();
            tb_AlkBeosztas = new TextBox();
            tb_AlkEmail = new TextBox();
            tb_AlkAdoazonositoJel = new TextBox();
            cb_AlkEngedelyezo = new ComboBox();
            cb_AlkVezeto = new ComboBox();
            cb_AlkHomeOfficeLehetoseg = new ComboBox();
            grpb_Szabadsag = new GroupBox();
            btn_SzabadsagModositasMegsem = new Button();
            btn_SzabadsagModositasMentes = new Button();
            btn_SzabadsagModositas = new Button();
            lb_AlkEvesSzabadsag = new Label();
            lb_EvesSzabadsag = new Label();
            tb_AlkEvesSzabadsag = new TextBox();
            btn_UjAlkalmazott = new Button();
            btn_FelhasznalhatoSzabadsag = new Button();
            btn_JelszoReset = new Button();
            btn_MunkaidoJovahagyas = new Button();
            btn_IgenylesJovahagyas = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_Alkalmazottak).BeginInit();
            ms_Menusor.SuspendLayout();
            grpb_AlkalmazottAdatai.SuspendLayout();
            grpb_Munkaviszony.SuspendLayout();
            grpb_Munkarend.SuspendLayout();
            grpb_AlkalmazottLakcim.SuspendLayout();
            grpb_Szabadsag.SuspendLayout();
            SuspendLayout();
            // 
            // dgv_Alkalmazottak
            // 
            dgv_Alkalmazottak.AllowUserToAddRows = false;
            dgv_Alkalmazottak.AllowUserToDeleteRows = false;
            dgv_Alkalmazottak.AllowUserToResizeColumns = false;
            dgv_Alkalmazottak.AllowUserToResizeRows = false;
            dgv_Alkalmazottak.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_Alkalmazottak.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Alkalmazottak.Location = new Point(124, 27);
            dgv_Alkalmazottak.MultiSelect = false;
            dgv_Alkalmazottak.Name = "dgv_Alkalmazottak";
            dgv_Alkalmazottak.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv_Alkalmazottak.Size = new Size(388, 633);
            dgv_Alkalmazottak.TabIndex = 0;
            dgv_Alkalmazottak.SelectionChanged += dgv_Alkalmazottak_SelectionChanged;
            // 
            // ms_Menusor
            // 
            ms_Menusor.BackColor = SystemColors.ControlLight;
            ms_Menusor.Items.AddRange(new ToolStripItem[] { tsmi_Program });
            ms_Menusor.Location = new Point(0, 0);
            ms_Menusor.Name = "ms_Menusor";
            ms_Menusor.Size = new Size(1127, 24);
            ms_Menusor.TabIndex = 1;
            ms_Menusor.Text = "menuStrip1";
            // 
            // tsmi_Program
            // 
            tsmi_Program.DropDownItems.AddRange(new ToolStripItem[] { tsmi_KilepesAProgrambol });
            tsmi_Program.Name = "tsmi_Program";
            tsmi_Program.Size = new Size(65, 20);
            tsmi_Program.Text = "Program";
            // 
            // tsmi_KilepesAProgrambol
            // 
            tsmi_KilepesAProgrambol.Name = "tsmi_KilepesAProgrambol";
            tsmi_KilepesAProgrambol.ShortcutKeys = Keys.Alt | Keys.F4;
            tsmi_KilepesAProgrambol.Size = new Size(228, 22);
            tsmi_KilepesAProgrambol.Text = "Kilépés a programból";
            tsmi_KilepesAProgrambol.Click += tsmi_KilepesAProgrambol_Click;
            // 
            // lb_beosztas
            // 
            lb_beosztas.AutoSize = true;
            lb_beosztas.Location = new Point(6, 242);
            lb_beosztas.Name = "lb_beosztas";
            lb_beosztas.Size = new Size(55, 15);
            lb_beosztas.TabIndex = 2;
            lb_beosztas.Text = "Beosztás:";
            // 
            // grpb_AlkalmazottAdatai
            // 
            grpb_AlkalmazottAdatai.Controls.Add(btn_AlkalmazottAdatainakModositasaMegsem);
            grpb_AlkalmazottAdatai.Controls.Add(btn_AlkalmazottAdatainakModositasaMentes);
            grpb_AlkalmazottAdatai.Controls.Add(btn_AlkalmazottAdatainakModositasa);
            grpb_AlkalmazottAdatai.Controls.Add(lb_Engedelyezo);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkEngedelyezo);
            grpb_AlkalmazottAdatai.Controls.Add(lb_Adminisztrator);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkAdminisztrator);
            grpb_AlkalmazottAdatai.Controls.Add(lb_HomeOfficeLehetoseg);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkHomeOfficeLehetoseg);
            grpb_AlkalmazottAdatai.Controls.Add(grpb_Munkaviszony);
            grpb_AlkalmazottAdatai.Controls.Add(lb_Vezeto);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkVezeto);
            grpb_AlkalmazottAdatai.Controls.Add(grpb_Munkarend);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AdoazonositoJel);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkAdoazonositoJel);
            grpb_AlkalmazottAdatai.Controls.Add(lb_email);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkEmail);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkAnyjaNeve);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AnyjaNeve);
            grpb_AlkalmazottAdatai.Controls.Add(grpb_AlkalmazottLakcim);
            grpb_AlkalmazottAdatai.Controls.Add(lb_beosztas);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkBeosztas);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkSzuletesiIdo);
            grpb_AlkalmazottAdatai.Controls.Add(lb_SzuletesiIdo);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkSzuletesiHely);
            grpb_AlkalmazottAdatai.Controls.Add(lb_SzuletesiHely);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AlkSzuletesiNev);
            grpb_AlkalmazottAdatai.Controls.Add(lb_SzuletesiNev);
            grpb_AlkalmazottAdatai.Controls.Add(dtp_AlkSzuletesiIdo);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkAnyjaNeve);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkSzuletesiHely);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkSzuletesiNev);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkBeosztas);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkEmail);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkAdoazonositoJel);
            grpb_AlkalmazottAdatai.Controls.Add(cb_AlkEngedelyezo);
            grpb_AlkalmazottAdatai.Controls.Add(cb_AlkVezeto);
            grpb_AlkalmazottAdatai.Controls.Add(cb_AlkHomeOfficeLehetoseg);
            grpb_AlkalmazottAdatai.Controls.Add(grpb_Szabadsag);
            grpb_AlkalmazottAdatai.Location = new Point(544, 27);
            grpb_AlkalmazottAdatai.Name = "grpb_AlkalmazottAdatai";
            grpb_AlkalmazottAdatai.Size = new Size(571, 633);
            grpb_AlkalmazottAdatai.TabIndex = 3;
            grpb_AlkalmazottAdatai.TabStop = false;
            grpb_AlkalmazottAdatai.Text = "Alkalmazott adatai";
            // 
            // btn_AlkalmazottAdatainakModositasaMegsem
            // 
            btn_AlkalmazottAdatainakModositasaMegsem.Location = new Point(490, 68);
            btn_AlkalmazottAdatainakModositasaMegsem.Name = "btn_AlkalmazottAdatainakModositasaMegsem";
            btn_AlkalmazottAdatainakModositasaMegsem.Size = new Size(75, 23);
            btn_AlkalmazottAdatainakModositasaMegsem.TabIndex = 31;
            btn_AlkalmazottAdatainakModositasaMegsem.Text = "mégsem";
            btn_AlkalmazottAdatainakModositasaMegsem.UseVisualStyleBackColor = true;
            btn_AlkalmazottAdatainakModositasaMegsem.Visible = false;
            btn_AlkalmazottAdatainakModositasaMegsem.Click += btn_AlkalmazottAdatainakModositasaMegsem_Click;
            // 
            // btn_AlkalmazottAdatainakModositasaMentes
            // 
            btn_AlkalmazottAdatainakModositasaMentes.Location = new Point(490, 39);
            btn_AlkalmazottAdatainakModositasaMentes.Name = "btn_AlkalmazottAdatainakModositasaMentes";
            btn_AlkalmazottAdatainakModositasaMentes.Size = new Size(75, 23);
            btn_AlkalmazottAdatainakModositasaMentes.TabIndex = 30;
            btn_AlkalmazottAdatainakModositasaMentes.Text = "mentés";
            btn_AlkalmazottAdatainakModositasaMentes.UseVisualStyleBackColor = true;
            btn_AlkalmazottAdatainakModositasaMentes.Visible = false;
            btn_AlkalmazottAdatainakModositasaMentes.Click += btn_AlkalmazottAdatainakModositasaMentese_Click;
            // 
            // btn_AlkalmazottAdatainakModositasa
            // 
            btn_AlkalmazottAdatainakModositasa.Location = new Point(465, 12);
            btn_AlkalmazottAdatainakModositasa.Name = "btn_AlkalmazottAdatainakModositasa";
            btn_AlkalmazottAdatainakModositasa.Size = new Size(100, 23);
            btn_AlkalmazottAdatainakModositasa.TabIndex = 5;
            btn_AlkalmazottAdatainakModositasa.Text = "adat módosítás";
            btn_AlkalmazottAdatainakModositasa.UseVisualStyleBackColor = true;
            btn_AlkalmazottAdatainakModositasa.Click += btn_AlkalmazottAdatainakModositasa_Click;
            // 
            // lb_Engedelyezo
            // 
            lb_Engedelyezo.AutoSize = true;
            lb_Engedelyezo.Location = new Point(301, 294);
            lb_Engedelyezo.Name = "lb_Engedelyezo";
            lb_Engedelyezo.Size = new Size(104, 15);
            lb_Engedelyezo.TabIndex = 23;
            lb_Engedelyezo.Text = "Engedélyező neve:";
            // 
            // lb_AlkEngedelyezo
            // 
            lb_AlkEngedelyezo.AutoSize = true;
            lb_AlkEngedelyezo.Location = new Point(411, 294);
            lb_AlkEngedelyezo.Name = "lb_AlkEngedelyezo";
            lb_AlkEngedelyezo.Size = new Size(13, 15);
            lb_AlkEngedelyezo.TabIndex = 24;
            lb_AlkEngedelyezo.Text = "a";
            // 
            // lb_Adminisztrator
            // 
            lb_Adminisztrator.AutoSize = true;
            lb_Adminisztrator.Location = new Point(6, 609);
            lb_Adminisztrator.Name = "lb_Adminisztrator";
            lb_Adminisztrator.Size = new Size(88, 15);
            lb_Adminisztrator.TabIndex = 21;
            lb_Adminisztrator.Text = "Adminisztrátor:";
            lb_Adminisztrator.DoubleClick += lb_Adminisztrator_DoubleClick;
            // 
            // lb_AlkAdminisztrator
            // 
            lb_AlkAdminisztrator.AutoSize = true;
            lb_AlkAdminisztrator.Location = new Point(93, 609);
            lb_AlkAdminisztrator.Name = "lb_AlkAdminisztrator";
            lb_AlkAdminisztrator.Size = new Size(13, 15);
            lb_AlkAdminisztrator.TabIndex = 22;
            lb_AlkAdminisztrator.Text = "a";
            // 
            // lb_HomeOfficeLehetoseg
            // 
            lb_HomeOfficeLehetoseg.AutoSize = true;
            lb_HomeOfficeLehetoseg.Location = new Point(301, 268);
            lb_HomeOfficeLehetoseg.Name = "lb_HomeOfficeLehetoseg";
            lb_HomeOfficeLehetoseg.Size = new Size(78, 15);
            lb_HomeOfficeLehetoseg.TabIndex = 19;
            lb_HomeOfficeLehetoseg.Text = "Home Office:";
            // 
            // lb_AlkHomeOfficeLehetoseg
            // 
            lb_AlkHomeOfficeLehetoseg.AutoSize = true;
            lb_AlkHomeOfficeLehetoseg.Location = new Point(411, 268);
            lb_AlkHomeOfficeLehetoseg.Name = "lb_AlkHomeOfficeLehetoseg";
            lb_AlkHomeOfficeLehetoseg.Size = new Size(13, 15);
            lb_AlkHomeOfficeLehetoseg.TabIndex = 20;
            lb_AlkHomeOfficeLehetoseg.Text = "a";
            // 
            // grpb_Munkaviszony
            // 
            grpb_Munkaviszony.Controls.Add(btn_MunkaviszonyModositasaMegsem);
            grpb_Munkaviszony.Controls.Add(btn_MunkaviszonyModositasaMentes);
            grpb_Munkaviszony.Controls.Add(btn_MunkaviszonyModositasa);
            grpb_Munkaviszony.Controls.Add(lb_AlkMunkaviszonyVege);
            grpb_Munkaviszony.Controls.Add(lb_MunkaviszonyVege);
            grpb_Munkaviszony.Controls.Add(lb_AlkMunkaviszonyKezdete);
            grpb_Munkaviszony.Controls.Add(lb_MunkaviszonyKezdete);
            grpb_Munkaviszony.Controls.Add(dtp_AlkMunkaviszonyKezdete);
            grpb_Munkaviszony.Controls.Add(dtp_AlkMunkaviszonyVege);
            grpb_Munkaviszony.Location = new Point(6, 318);
            grpb_Munkaviszony.Name = "grpb_Munkaviszony";
            grpb_Munkaviszony.Size = new Size(559, 89);
            grpb_Munkaviszony.TabIndex = 17;
            grpb_Munkaviszony.TabStop = false;
            grpb_Munkaviszony.Text = "Munkaviszony";
            // 
            // btn_MunkaviszonyModositasaMegsem
            // 
            btn_MunkaviszonyModositasaMegsem.Location = new Point(478, 60);
            btn_MunkaviszonyModositasaMegsem.Name = "btn_MunkaviszonyModositasaMegsem";
            btn_MunkaviszonyModositasaMegsem.Size = new Size(75, 23);
            btn_MunkaviszonyModositasaMegsem.TabIndex = 35;
            btn_MunkaviszonyModositasaMegsem.Text = "mégsem";
            btn_MunkaviszonyModositasaMegsem.UseVisualStyleBackColor = true;
            btn_MunkaviszonyModositasaMegsem.Visible = false;
            btn_MunkaviszonyModositasaMegsem.Click += btn_MunkaviszonyModositasaMegsem_Click;
            // 
            // btn_MunkaviszonyModositasaMentes
            // 
            btn_MunkaviszonyModositasaMentes.Location = new Point(397, 60);
            btn_MunkaviszonyModositasaMentes.Name = "btn_MunkaviszonyModositasaMentes";
            btn_MunkaviszonyModositasaMentes.Size = new Size(75, 23);
            btn_MunkaviszonyModositasaMentes.TabIndex = 34;
            btn_MunkaviszonyModositasaMentes.Text = "mentés";
            btn_MunkaviszonyModositasaMentes.UseVisualStyleBackColor = true;
            btn_MunkaviszonyModositasaMentes.Visible = false;
            btn_MunkaviszonyModositasaMentes.Click += btn_MunkaviszonyModositasaMentes_Click;
            // 
            // btn_MunkaviszonyModositasa
            // 
            btn_MunkaviszonyModositasa.Location = new Point(6, 60);
            btn_MunkaviszonyModositasa.Name = "btn_MunkaviszonyModositasa";
            btn_MunkaviszonyModositasa.Size = new Size(159, 23);
            btn_MunkaviszonyModositasa.TabIndex = 13;
            btn_MunkaviszonyModositasa.Text = "munkaviszony módosítás";
            btn_MunkaviszonyModositasa.UseVisualStyleBackColor = true;
            btn_MunkaviszonyModositasa.Click += btn_MunkaviszonyModositasa_Click;
            // 
            // lb_AlkMunkaviszonyVege
            // 
            lb_AlkMunkaviszonyVege.AutoSize = true;
            lb_AlkMunkaviszonyVege.Location = new Point(405, 30);
            lb_AlkMunkaviszonyVege.Name = "lb_AlkMunkaviszonyVege";
            lb_AlkMunkaviszonyVege.Size = new Size(13, 15);
            lb_AlkMunkaviszonyVege.TabIndex = 7;
            lb_AlkMunkaviszonyVege.Text = "a";
            // 
            // lb_MunkaviszonyVege
            // 
            lb_MunkaviszonyVege.AutoSize = true;
            lb_MunkaviszonyVege.Location = new Point(295, 30);
            lb_MunkaviszonyVege.Name = "lb_MunkaviszonyVege";
            lb_MunkaviszonyVege.Size = new Size(114, 15);
            lb_MunkaviszonyVege.TabIndex = 6;
            lb_MunkaviszonyVege.Text = "Munkaviszony vége:";
            // 
            // lb_AlkMunkaviszonyKezdete
            // 
            lb_AlkMunkaviszonyKezdete.AutoSize = true;
            lb_AlkMunkaviszonyKezdete.Location = new Point(135, 30);
            lb_AlkMunkaviszonyKezdete.Name = "lb_AlkMunkaviszonyKezdete";
            lb_AlkMunkaviszonyKezdete.Size = new Size(13, 15);
            lb_AlkMunkaviszonyKezdete.TabIndex = 5;
            lb_AlkMunkaviszonyKezdete.Text = "a";
            // 
            // lb_MunkaviszonyKezdete
            // 
            lb_MunkaviszonyKezdete.AutoSize = true;
            lb_MunkaviszonyKezdete.Location = new Point(6, 30);
            lb_MunkaviszonyKezdete.Name = "lb_MunkaviszonyKezdete";
            lb_MunkaviszonyKezdete.Size = new Size(129, 15);
            lb_MunkaviszonyKezdete.TabIndex = 4;
            lb_MunkaviszonyKezdete.Text = "Munkaviszony kezdete:";
            // 
            // dtp_AlkMunkaviszonyKezdete
            // 
            dtp_AlkMunkaviszonyKezdete.Format = DateTimePickerFormat.Short;
            dtp_AlkMunkaviszonyKezdete.Location = new Point(137, 26);
            dtp_AlkMunkaviszonyKezdete.Name = "dtp_AlkMunkaviszonyKezdete";
            dtp_AlkMunkaviszonyKezdete.Size = new Size(140, 23);
            dtp_AlkMunkaviszonyKezdete.TabIndex = 30;
            dtp_AlkMunkaviszonyKezdete.Visible = false;
            // 
            // dtp_AlkMunkaviszonyVege
            // 
            dtp_AlkMunkaviszonyVege.Format = DateTimePickerFormat.Short;
            dtp_AlkMunkaviszonyVege.Location = new Point(410, 26);
            dtp_AlkMunkaviszonyVege.Name = "dtp_AlkMunkaviszonyVege";
            dtp_AlkMunkaviszonyVege.Size = new Size(140, 23);
            dtp_AlkMunkaviszonyVege.TabIndex = 31;
            dtp_AlkMunkaviszonyVege.Visible = false;
            // 
            // lb_Vezeto
            // 
            lb_Vezeto.AutoSize = true;
            lb_Vezeto.Location = new Point(301, 242);
            lb_Vezeto.Name = "lb_Vezeto";
            lb_Vezeto.Size = new Size(44, 15);
            lb_Vezeto.TabIndex = 17;
            lb_Vezeto.Text = "Vezető:";
            // 
            // lb_AlkVezeto
            // 
            lb_AlkVezeto.AutoSize = true;
            lb_AlkVezeto.Location = new Point(411, 242);
            lb_AlkVezeto.Name = "lb_AlkVezeto";
            lb_AlkVezeto.Size = new Size(13, 15);
            lb_AlkVezeto.TabIndex = 18;
            lb_AlkVezeto.Text = "a";
            // 
            // grpb_Munkarend
            // 
            grpb_Munkarend.Controls.Add(btn_MunkaidoModositasMegsem);
            grpb_Munkarend.Controls.Add(btn_MunkaidoModositasMentes);
            grpb_Munkarend.Controls.Add(btn_MunkaidoModositas);
            grpb_Munkarend.Controls.Add(lb_AlkEbedszunetVege);
            grpb_Munkarend.Controls.Add(lb_EbedszunetVege);
            grpb_Munkarend.Controls.Add(lb_AlkEbedszunetKezdete);
            grpb_Munkarend.Controls.Add(lb_EbedszunetKezdete);
            grpb_Munkarend.Controls.Add(lb_AlkMunkaidoVege);
            grpb_Munkarend.Controls.Add(lb_MunkaidoVege);
            grpb_Munkarend.Controls.Add(lb_AlkMunkaidoKezdete);
            grpb_Munkarend.Controls.Add(lb_MunkaidoKezdete);
            grpb_Munkarend.Controls.Add(cb_AlkMunkaidoKezdete);
            grpb_Munkarend.Controls.Add(cb_AlkMunkaidoVege);
            grpb_Munkarend.Controls.Add(cb_AlkEbedidoKezdete);
            grpb_Munkarend.Controls.Add(cb_AlkEbedidoVege);
            grpb_Munkarend.Location = new Point(6, 407);
            grpb_Munkarend.Name = "grpb_Munkarend";
            grpb_Munkarend.Size = new Size(559, 105);
            grpb_Munkarend.TabIndex = 16;
            grpb_Munkarend.TabStop = false;
            grpb_Munkarend.Text = "Munkaidő";
            // 
            // btn_MunkaidoModositasMegsem
            // 
            btn_MunkaidoModositasMegsem.Location = new Point(478, 76);
            btn_MunkaidoModositasMegsem.Name = "btn_MunkaidoModositasMegsem";
            btn_MunkaidoModositasMegsem.Size = new Size(75, 23);
            btn_MunkaidoModositasMegsem.TabIndex = 37;
            btn_MunkaidoModositasMegsem.Text = "mégsem";
            btn_MunkaidoModositasMegsem.UseVisualStyleBackColor = true;
            btn_MunkaidoModositasMegsem.Visible = false;
            btn_MunkaidoModositasMegsem.Click += btn_MunkaidoModositasMegsem_Click;
            // 
            // btn_MunkaidoModositasMentes
            // 
            btn_MunkaidoModositasMentes.Location = new Point(397, 76);
            btn_MunkaidoModositasMentes.Name = "btn_MunkaidoModositasMentes";
            btn_MunkaidoModositasMentes.Size = new Size(75, 23);
            btn_MunkaidoModositasMentes.TabIndex = 36;
            btn_MunkaidoModositasMentes.Text = "mentés";
            btn_MunkaidoModositasMentes.UseVisualStyleBackColor = true;
            btn_MunkaidoModositasMentes.Visible = false;
            btn_MunkaidoModositasMentes.Click += btn_MunkaidoModositasMentes_Click;
            // 
            // btn_MunkaidoModositas
            // 
            btn_MunkaidoModositas.Location = new Point(6, 76);
            btn_MunkaidoModositas.Name = "btn_MunkaidoModositas";
            btn_MunkaidoModositas.Size = new Size(148, 23);
            btn_MunkaidoModositas.TabIndex = 12;
            btn_MunkaidoModositas.Text = "munkaidő módosítás";
            btn_MunkaidoModositas.UseVisualStyleBackColor = true;
            btn_MunkaidoModositas.Click += btn_MunkaidoModositas_Click;
            // 
            // lb_AlkEbedszunetVege
            // 
            lb_AlkEbedszunetVege.AutoSize = true;
            lb_AlkEbedszunetVege.Location = new Point(405, 54);
            lb_AlkEbedszunetVege.Name = "lb_AlkEbedszunetVege";
            lb_AlkEbedszunetVege.Size = new Size(13, 15);
            lb_AlkEbedszunetVege.TabIndex = 11;
            lb_AlkEbedszunetVege.Text = "a";
            // 
            // lb_EbedszunetVege
            // 
            lb_EbedszunetVege.AutoSize = true;
            lb_EbedszunetVege.Location = new Point(295, 54);
            lb_EbedszunetVege.Name = "lb_EbedszunetVege";
            lb_EbedszunetVege.Size = new Size(98, 15);
            lb_EbedszunetVege.TabIndex = 10;
            lb_EbedszunetVege.Text = "Ebédszünet vége:";
            // 
            // lb_AlkEbedszunetKezdete
            // 
            lb_AlkEbedszunetKezdete.AutoSize = true;
            lb_AlkEbedszunetKezdete.Location = new Point(405, 30);
            lb_AlkEbedszunetKezdete.Name = "lb_AlkEbedszunetKezdete";
            lb_AlkEbedszunetKezdete.Size = new Size(13, 15);
            lb_AlkEbedszunetKezdete.TabIndex = 9;
            lb_AlkEbedszunetKezdete.Text = "a";
            // 
            // lb_EbedszunetKezdete
            // 
            lb_EbedszunetKezdete.AutoSize = true;
            lb_EbedszunetKezdete.Location = new Point(295, 30);
            lb_EbedszunetKezdete.Name = "lb_EbedszunetKezdete";
            lb_EbedszunetKezdete.Size = new Size(113, 15);
            lb_EbedszunetKezdete.TabIndex = 8;
            lb_EbedszunetKezdete.Text = "Ebédszünet kezdete:";
            // 
            // lb_AlkMunkaidoVege
            // 
            lb_AlkMunkaidoVege.AutoSize = true;
            lb_AlkMunkaidoVege.Location = new Point(116, 54);
            lb_AlkMunkaidoVege.Name = "lb_AlkMunkaidoVege";
            lb_AlkMunkaidoVege.Size = new Size(13, 15);
            lb_AlkMunkaidoVege.TabIndex = 7;
            lb_AlkMunkaidoVege.Text = "a";
            // 
            // lb_MunkaidoVege
            // 
            lb_MunkaidoVege.AutoSize = true;
            lb_MunkaidoVege.Location = new Point(6, 54);
            lb_MunkaidoVege.Name = "lb_MunkaidoVege";
            lb_MunkaidoVege.Size = new Size(92, 15);
            lb_MunkaidoVege.TabIndex = 6;
            lb_MunkaidoVege.Text = "Munkaidő vége:";
            // 
            // lb_AlkMunkaidoKezdete
            // 
            lb_AlkMunkaidoKezdete.AutoSize = true;
            lb_AlkMunkaidoKezdete.Location = new Point(116, 30);
            lb_AlkMunkaidoKezdete.Name = "lb_AlkMunkaidoKezdete";
            lb_AlkMunkaidoKezdete.Size = new Size(13, 15);
            lb_AlkMunkaidoKezdete.TabIndex = 5;
            lb_AlkMunkaidoKezdete.Text = "a";
            // 
            // lb_MunkaidoKezdete
            // 
            lb_MunkaidoKezdete.AutoSize = true;
            lb_MunkaidoKezdete.Location = new Point(6, 30);
            lb_MunkaidoKezdete.Name = "lb_MunkaidoKezdete";
            lb_MunkaidoKezdete.Size = new Size(107, 15);
            lb_MunkaidoKezdete.TabIndex = 4;
            lb_MunkaidoKezdete.Text = "Munkaidő kezdete:";
            // 
            // cb_AlkMunkaidoKezdete
            // 
            cb_AlkMunkaidoKezdete.FormattingEnabled = true;
            cb_AlkMunkaidoKezdete.Items.AddRange(new object[] { "00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30" });
            cb_AlkMunkaidoKezdete.Location = new Point(119, 26);
            cb_AlkMunkaidoKezdete.Name = "cb_AlkMunkaidoKezdete";
            cb_AlkMunkaidoKezdete.Size = new Size(121, 23);
            cb_AlkMunkaidoKezdete.TabIndex = 46;
            cb_AlkMunkaidoKezdete.Visible = false;
            // 
            // cb_AlkMunkaidoVege
            // 
            cb_AlkMunkaidoVege.FormattingEnabled = true;
            cb_AlkMunkaidoVege.Items.AddRange(new object[] { "00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30" });
            cb_AlkMunkaidoVege.Location = new Point(119, 50);
            cb_AlkMunkaidoVege.Name = "cb_AlkMunkaidoVege";
            cb_AlkMunkaidoVege.Size = new Size(121, 23);
            cb_AlkMunkaidoVege.TabIndex = 47;
            cb_AlkMunkaidoVege.Visible = false;
            // 
            // cb_AlkEbedidoKezdete
            // 
            cb_AlkEbedidoKezdete.FormattingEnabled = true;
            cb_AlkEbedidoKezdete.Items.AddRange(new object[] { "00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30" });
            cb_AlkEbedidoKezdete.Location = new Point(408, 26);
            cb_AlkEbedidoKezdete.Name = "cb_AlkEbedidoKezdete";
            cb_AlkEbedidoKezdete.Size = new Size(121, 23);
            cb_AlkEbedidoKezdete.TabIndex = 48;
            cb_AlkEbedidoKezdete.Visible = false;
            // 
            // cb_AlkEbedidoVege
            // 
            cb_AlkEbedidoVege.FormattingEnabled = true;
            cb_AlkEbedidoVege.Items.AddRange(new object[] { "00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30" });
            cb_AlkEbedidoVege.Location = new Point(408, 50);
            cb_AlkEbedidoVege.Name = "cb_AlkEbedidoVege";
            cb_AlkEbedidoVege.Size = new Size(121, 23);
            cb_AlkEbedidoVege.TabIndex = 49;
            cb_AlkEbedidoVege.Visible = false;
            // 
            // lb_AdoazonositoJel
            // 
            lb_AdoazonositoJel.AutoSize = true;
            lb_AdoazonositoJel.Location = new Point(6, 294);
            lb_AdoazonositoJel.Name = "lb_AdoazonositoJel";
            lb_AdoazonositoJel.Size = new Size(46, 15);
            lb_AdoazonositoJel.TabIndex = 14;
            lb_AdoazonositoJel.Text = "Adóaz.:";
            // 
            // lb_AlkAdoazonositoJel
            // 
            lb_AlkAdoazonositoJel.AutoSize = true;
            lb_AlkAdoazonositoJel.Location = new Point(70, 294);
            lb_AlkAdoazonositoJel.Name = "lb_AlkAdoazonositoJel";
            lb_AlkAdoazonositoJel.Size = new Size(13, 15);
            lb_AlkAdoazonositoJel.TabIndex = 15;
            lb_AlkAdoazonositoJel.Text = "a";
            // 
            // lb_email
            // 
            lb_email.AutoSize = true;
            lb_email.Location = new Point(6, 268);
            lb_email.Name = "lb_email";
            lb_email.Size = new Size(44, 15);
            lb_email.TabIndex = 12;
            lb_email.Text = "E-mail:";
            // 
            // lb_AlkEmail
            // 
            lb_AlkEmail.AutoSize = true;
            lb_AlkEmail.Location = new Point(70, 268);
            lb_AlkEmail.Name = "lb_AlkEmail";
            lb_AlkEmail.Size = new Size(13, 15);
            lb_AlkEmail.TabIndex = 13;
            lb_AlkEmail.Text = "a";
            // 
            // lb_AlkAnyjaNeve
            // 
            lb_AlkAnyjaNeve.AutoSize = true;
            lb_AlkAnyjaNeve.Location = new Point(70, 92);
            lb_AlkAnyjaNeve.Name = "lb_AlkAnyjaNeve";
            lb_AlkAnyjaNeve.Size = new Size(13, 15);
            lb_AlkAnyjaNeve.TabIndex = 11;
            lb_AlkAnyjaNeve.Text = "a";
            // 
            // lb_AnyjaNeve
            // 
            lb_AnyjaNeve.AutoSize = true;
            lb_AnyjaNeve.Location = new Point(6, 92);
            lb_AnyjaNeve.Name = "lb_AnyjaNeve";
            lb_AnyjaNeve.Size = new Size(68, 15);
            lb_AnyjaNeve.TabIndex = 10;
            lb_AnyjaNeve.Text = "Anyja neve:";
            // 
            // grpb_AlkalmazottLakcim
            // 
            grpb_AlkalmazottLakcim.Controls.Add(btn_LakcimModositasaMegsem);
            grpb_AlkalmazottLakcim.Controls.Add(btn_LakcimModositasaMentes);
            grpb_AlkalmazottLakcim.Controls.Add(btn_LakcimModositasa);
            grpb_AlkalmazottLakcim.Controls.Add(lb_AlkIranyitoszam);
            grpb_AlkalmazottLakcim.Controls.Add(lb_Iranyitoszam);
            grpb_AlkalmazottLakcim.Controls.Add(lb_AlkCim);
            grpb_AlkalmazottLakcim.Controls.Add(lb_Cim);
            grpb_AlkalmazottLakcim.Controls.Add(lb_AlkTelepulesNeve);
            grpb_AlkalmazottLakcim.Controls.Add(lb_TelepulesNeve);
            grpb_AlkalmazottLakcim.Controls.Add(tb_AlkIranyitoszam);
            grpb_AlkalmazottLakcim.Controls.Add(tb_AlkCim);
            grpb_AlkalmazottLakcim.Controls.Add(tb_AlkTelepulesNeve);
            grpb_AlkalmazottLakcim.Location = new Point(6, 126);
            grpb_AlkalmazottLakcim.Name = "grpb_AlkalmazottLakcim";
            grpb_AlkalmazottLakcim.Size = new Size(559, 104);
            grpb_AlkalmazottLakcim.TabIndex = 4;
            grpb_AlkalmazottLakcim.TabStop = false;
            grpb_AlkalmazottLakcim.Text = "Lakcím";
            // 
            // btn_LakcimModositasaMegsem
            // 
            btn_LakcimModositasaMegsem.Location = new Point(478, 69);
            btn_LakcimModositasaMegsem.Name = "btn_LakcimModositasaMegsem";
            btn_LakcimModositasaMegsem.Size = new Size(75, 23);
            btn_LakcimModositasaMegsem.TabIndex = 33;
            btn_LakcimModositasaMegsem.Text = "mégsem";
            btn_LakcimModositasaMegsem.UseVisualStyleBackColor = true;
            btn_LakcimModositasaMegsem.Visible = false;
            btn_LakcimModositasaMegsem.Click += btn_LakcimModositasaMegsem_Click;
            // 
            // btn_LakcimModositasaMentes
            // 
            btn_LakcimModositasaMentes.Location = new Point(478, 40);
            btn_LakcimModositasaMentes.Name = "btn_LakcimModositasaMentes";
            btn_LakcimModositasaMentes.Size = new Size(75, 23);
            btn_LakcimModositasaMentes.TabIndex = 32;
            btn_LakcimModositasaMentes.Text = "mentés";
            btn_LakcimModositasaMentes.UseVisualStyleBackColor = true;
            btn_LakcimModositasaMentes.Visible = false;
            btn_LakcimModositasaMentes.Click += btn_LakcimModositasaMentese_Click;
            // 
            // btn_LakcimModositasa
            // 
            btn_LakcimModositasa.Location = new Point(434, 11);
            btn_LakcimModositasa.Name = "btn_LakcimModositasa";
            btn_LakcimModositasa.Size = new Size(119, 23);
            btn_LakcimModositasa.TabIndex = 10;
            btn_LakcimModositasa.Text = "lakcím módosítás";
            btn_LakcimModositasa.UseVisualStyleBackColor = true;
            btn_LakcimModositasa.Click += btn_LakcimModositasa_Click;
            // 
            // lb_AlkIranyitoszam
            // 
            lb_AlkIranyitoszam.AutoSize = true;
            lb_AlkIranyitoszam.Location = new Point(87, 78);
            lb_AlkIranyitoszam.Name = "lb_AlkIranyitoszam";
            lb_AlkIranyitoszam.Size = new Size(13, 15);
            lb_AlkIranyitoszam.TabIndex = 9;
            lb_AlkIranyitoszam.Text = "a";
            // 
            // lb_Iranyitoszam
            // 
            lb_Iranyitoszam.AutoSize = true;
            lb_Iranyitoszam.Location = new Point(6, 78);
            lb_Iranyitoszam.Name = "lb_Iranyitoszam";
            lb_Iranyitoszam.Size = new Size(77, 15);
            lb_Iranyitoszam.TabIndex = 8;
            lb_Iranyitoszam.Text = "Irányítószám:";
            // 
            // lb_AlkCim
            // 
            lb_AlkCim.AutoSize = true;
            lb_AlkCim.Location = new Point(87, 54);
            lb_AlkCim.Name = "lb_AlkCim";
            lb_AlkCim.Size = new Size(13, 15);
            lb_AlkCim.TabIndex = 7;
            lb_AlkCim.Text = "a";
            // 
            // lb_Cim
            // 
            lb_Cim.AutoSize = true;
            lb_Cim.Location = new Point(6, 54);
            lb_Cim.Name = "lb_Cim";
            lb_Cim.Size = new Size(32, 15);
            lb_Cim.TabIndex = 6;
            lb_Cim.Text = "Cím:";
            // 
            // lb_AlkTelepulesNeve
            // 
            lb_AlkTelepulesNeve.AutoSize = true;
            lb_AlkTelepulesNeve.Location = new Point(87, 30);
            lb_AlkTelepulesNeve.Name = "lb_AlkTelepulesNeve";
            lb_AlkTelepulesNeve.Size = new Size(13, 15);
            lb_AlkTelepulesNeve.TabIndex = 5;
            lb_AlkTelepulesNeve.Text = "a";
            // 
            // lb_TelepulesNeve
            // 
            lb_TelepulesNeve.AutoSize = true;
            lb_TelepulesNeve.Location = new Point(6, 30);
            lb_TelepulesNeve.Name = "lb_TelepulesNeve";
            lb_TelepulesNeve.Size = new Size(58, 15);
            lb_TelepulesNeve.TabIndex = 4;
            lb_TelepulesNeve.Text = "Település:";
            // 
            // tb_AlkIranyitoszam
            // 
            tb_AlkIranyitoszam.Location = new Point(87, 73);
            tb_AlkIranyitoszam.MaxLength = 4;
            tb_AlkIranyitoszam.Name = "tb_AlkIranyitoszam";
            tb_AlkIranyitoszam.Size = new Size(262, 23);
            tb_AlkIranyitoszam.TabIndex = 31;
            tb_AlkIranyitoszam.Visible = false;
            tb_AlkIranyitoszam.KeyPress += tb_AlkIranyitoszam_KeyPress;
            tb_AlkIranyitoszam.PreviewKeyDown += tb_AlkIranyitoszam_PreviewKeyDown;
            // 
            // tb_AlkCim
            // 
            tb_AlkCim.Location = new Point(87, 49);
            tb_AlkCim.Name = "tb_AlkCim";
            tb_AlkCim.Size = new Size(262, 23);
            tb_AlkCim.TabIndex = 30;
            tb_AlkCim.Visible = false;
            // 
            // tb_AlkTelepulesNeve
            // 
            tb_AlkTelepulesNeve.Location = new Point(87, 25);
            tb_AlkTelepulesNeve.Name = "tb_AlkTelepulesNeve";
            tb_AlkTelepulesNeve.Size = new Size(262, 23);
            tb_AlkTelepulesNeve.TabIndex = 29;
            tb_AlkTelepulesNeve.Visible = false;
            // 
            // lb_AlkBeosztas
            // 
            lb_AlkBeosztas.AutoSize = true;
            lb_AlkBeosztas.Location = new Point(70, 242);
            lb_AlkBeosztas.Name = "lb_AlkBeosztas";
            lb_AlkBeosztas.Size = new Size(13, 15);
            lb_AlkBeosztas.TabIndex = 3;
            lb_AlkBeosztas.Text = "a";
            // 
            // lb_AlkSzuletesiIdo
            // 
            lb_AlkSzuletesiIdo.AutoSize = true;
            lb_AlkSzuletesiIdo.Location = new Point(70, 68);
            lb_AlkSzuletesiIdo.Name = "lb_AlkSzuletesiIdo";
            lb_AlkSzuletesiIdo.Size = new Size(13, 15);
            lb_AlkSzuletesiIdo.TabIndex = 9;
            lb_AlkSzuletesiIdo.Text = "a";
            // 
            // lb_SzuletesiIdo
            // 
            lb_SzuletesiIdo.AutoSize = true;
            lb_SzuletesiIdo.Location = new Point(6, 68);
            lb_SzuletesiIdo.Name = "lb_SzuletesiIdo";
            lb_SzuletesiIdo.Size = new Size(54, 15);
            lb_SzuletesiIdo.TabIndex = 8;
            lb_SzuletesiIdo.Text = "Szül. idő:";
            // 
            // lb_AlkSzuletesiHely
            // 
            lb_AlkSzuletesiHely.AutoSize = true;
            lb_AlkSzuletesiHely.Location = new Point(70, 44);
            lb_AlkSzuletesiHely.Name = "lb_AlkSzuletesiHely";
            lb_AlkSzuletesiHely.Size = new Size(13, 15);
            lb_AlkSzuletesiHely.TabIndex = 7;
            lb_AlkSzuletesiHely.Text = "a";
            // 
            // lb_SzuletesiHely
            // 
            lb_SzuletesiHely.AutoSize = true;
            lb_SzuletesiHely.Location = new Point(6, 44);
            lb_SzuletesiHely.Name = "lb_SzuletesiHely";
            lb_SzuletesiHely.Size = new Size(59, 15);
            lb_SzuletesiHely.TabIndex = 6;
            lb_SzuletesiHely.Text = "Szül. hely:";
            // 
            // lb_AlkSzuletesiNev
            // 
            lb_AlkSzuletesiNev.AutoSize = true;
            lb_AlkSzuletesiNev.Location = new Point(70, 20);
            lb_AlkSzuletesiNev.Name = "lb_AlkSzuletesiNev";
            lb_AlkSzuletesiNev.Size = new Size(13, 15);
            lb_AlkSzuletesiNev.TabIndex = 5;
            lb_AlkSzuletesiNev.Text = "a";
            // 
            // lb_SzuletesiNev
            // 
            lb_SzuletesiNev.AutoSize = true;
            lb_SzuletesiNev.Location = new Point(6, 20);
            lb_SzuletesiNev.Name = "lb_SzuletesiNev";
            lb_SzuletesiNev.Size = new Size(31, 15);
            lb_SzuletesiNev.TabIndex = 4;
            lb_SzuletesiNev.Text = "Név:";
            // 
            // dtp_AlkSzuletesiIdo
            // 
            dtp_AlkSzuletesiIdo.Format = DateTimePickerFormat.Short;
            dtp_AlkSzuletesiIdo.Location = new Point(74, 65);
            dtp_AlkSzuletesiIdo.Name = "dtp_AlkSzuletesiIdo";
            dtp_AlkSzuletesiIdo.Size = new Size(262, 23);
            dtp_AlkSzuletesiIdo.TabIndex = 29;
            dtp_AlkSzuletesiIdo.Visible = false;
            // 
            // tb_AlkAnyjaNeve
            // 
            tb_AlkAnyjaNeve.Location = new Point(74, 89);
            tb_AlkAnyjaNeve.Name = "tb_AlkAnyjaNeve";
            tb_AlkAnyjaNeve.Size = new Size(262, 23);
            tb_AlkAnyjaNeve.TabIndex = 28;
            tb_AlkAnyjaNeve.Visible = false;
            // 
            // tb_AlkSzuletesiHely
            // 
            tb_AlkSzuletesiHely.Location = new Point(74, 41);
            tb_AlkSzuletesiHely.Name = "tb_AlkSzuletesiHely";
            tb_AlkSzuletesiHely.Size = new Size(262, 23);
            tb_AlkSzuletesiHely.TabIndex = 26;
            tb_AlkSzuletesiHely.Visible = false;
            // 
            // tb_AlkSzuletesiNev
            // 
            tb_AlkSzuletesiNev.Location = new Point(74, 17);
            tb_AlkSzuletesiNev.Name = "tb_AlkSzuletesiNev";
            tb_AlkSzuletesiNev.Size = new Size(262, 23);
            tb_AlkSzuletesiNev.TabIndex = 25;
            tb_AlkSzuletesiNev.Visible = false;
            // 
            // tb_AlkBeosztas
            // 
            tb_AlkBeosztas.Location = new Point(74, 239);
            tb_AlkBeosztas.Name = "tb_AlkBeosztas";
            tb_AlkBeosztas.Size = new Size(189, 23);
            tb_AlkBeosztas.TabIndex = 32;
            tb_AlkBeosztas.Visible = false;
            // 
            // tb_AlkEmail
            // 
            tb_AlkEmail.Location = new Point(74, 265);
            tb_AlkEmail.Name = "tb_AlkEmail";
            tb_AlkEmail.Size = new Size(189, 23);
            tb_AlkEmail.TabIndex = 33;
            tb_AlkEmail.Visible = false;
            // 
            // tb_AlkAdoazonositoJel
            // 
            tb_AlkAdoazonositoJel.Location = new Point(74, 291);
            tb_AlkAdoazonositoJel.Name = "tb_AlkAdoazonositoJel";
            tb_AlkAdoazonositoJel.Size = new Size(189, 23);
            tb_AlkAdoazonositoJel.TabIndex = 34;
            tb_AlkAdoazonositoJel.Visible = false;
            // 
            // cb_AlkEngedelyezo
            // 
            cb_AlkEngedelyezo.FormattingEnabled = true;
            cb_AlkEngedelyezo.Location = new Point(414, 291);
            cb_AlkEngedelyezo.Name = "cb_AlkEngedelyezo";
            cb_AlkEngedelyezo.Size = new Size(121, 23);
            cb_AlkEngedelyezo.TabIndex = 47;
            cb_AlkEngedelyezo.Visible = false;
            // 
            // cb_AlkVezeto
            // 
            cb_AlkVezeto.FormattingEnabled = true;
            cb_AlkVezeto.Items.AddRange(new object[] { "I", "N" });
            cb_AlkVezeto.Location = new Point(414, 239);
            cb_AlkVezeto.Name = "cb_AlkVezeto";
            cb_AlkVezeto.Size = new Size(121, 23);
            cb_AlkVezeto.TabIndex = 49;
            cb_AlkVezeto.Visible = false;
            // 
            // cb_AlkHomeOfficeLehetoseg
            // 
            cb_AlkHomeOfficeLehetoseg.FormattingEnabled = true;
            cb_AlkHomeOfficeLehetoseg.Items.AddRange(new object[] { "I", "N" });
            cb_AlkHomeOfficeLehetoseg.Location = new Point(414, 265);
            cb_AlkHomeOfficeLehetoseg.Name = "cb_AlkHomeOfficeLehetoseg";
            cb_AlkHomeOfficeLehetoseg.Size = new Size(121, 23);
            cb_AlkHomeOfficeLehetoseg.TabIndex = 48;
            cb_AlkHomeOfficeLehetoseg.Visible = false;
            // 
            // grpb_Szabadsag
            // 
            grpb_Szabadsag.Controls.Add(btn_SzabadsagModositasMegsem);
            grpb_Szabadsag.Controls.Add(btn_SzabadsagModositasMentes);
            grpb_Szabadsag.Controls.Add(btn_SzabadsagModositas);
            grpb_Szabadsag.Controls.Add(lb_AlkEvesSzabadsag);
            grpb_Szabadsag.Controls.Add(lb_EvesSzabadsag);
            grpb_Szabadsag.Controls.Add(tb_AlkEvesSzabadsag);
            grpb_Szabadsag.Location = new Point(6, 514);
            grpb_Szabadsag.Name = "grpb_Szabadsag";
            grpb_Szabadsag.Size = new Size(559, 87);
            grpb_Szabadsag.TabIndex = 17;
            grpb_Szabadsag.TabStop = false;
            grpb_Szabadsag.Text = "Szabadság";
            // 
            // btn_SzabadsagModositasMegsem
            // 
            btn_SzabadsagModositasMegsem.Location = new Point(478, 56);
            btn_SzabadsagModositasMegsem.Name = "btn_SzabadsagModositasMegsem";
            btn_SzabadsagModositasMegsem.Size = new Size(75, 23);
            btn_SzabadsagModositasMegsem.TabIndex = 37;
            btn_SzabadsagModositasMegsem.Text = "mégsem";
            btn_SzabadsagModositasMegsem.UseVisualStyleBackColor = true;
            btn_SzabadsagModositasMegsem.Visible = false;
            btn_SzabadsagModositasMegsem.Click += btn_SzabadsagModositasMegsem_Click;
            // 
            // btn_SzabadsagModositasMentes
            // 
            btn_SzabadsagModositasMentes.Location = new Point(397, 56);
            btn_SzabadsagModositasMentes.Name = "btn_SzabadsagModositasMentes";
            btn_SzabadsagModositasMentes.Size = new Size(75, 23);
            btn_SzabadsagModositasMentes.TabIndex = 36;
            btn_SzabadsagModositasMentes.Text = "mentés";
            btn_SzabadsagModositasMentes.UseVisualStyleBackColor = true;
            btn_SzabadsagModositasMentes.Visible = false;
            btn_SzabadsagModositasMentes.Click += btn_SzabadsagModositasMentes_Click;
            // 
            // btn_SzabadsagModositas
            // 
            btn_SzabadsagModositas.Location = new Point(6, 56);
            btn_SzabadsagModositas.Name = "btn_SzabadsagModositas";
            btn_SzabadsagModositas.Size = new Size(148, 23);
            btn_SzabadsagModositas.TabIndex = 12;
            btn_SzabadsagModositas.Text = "szabadság módosítás";
            btn_SzabadsagModositas.UseVisualStyleBackColor = true;
            btn_SzabadsagModositas.Click += btn_SzabadsagModositas_Click;
            // 
            // lb_AlkEvesSzabadsag
            // 
            lb_AlkEvesSzabadsag.AutoSize = true;
            lb_AlkEvesSzabadsag.Location = new Point(116, 30);
            lb_AlkEvesSzabadsag.Name = "lb_AlkEvesSzabadsag";
            lb_AlkEvesSzabadsag.Size = new Size(13, 15);
            lb_AlkEvesSzabadsag.TabIndex = 5;
            lb_AlkEvesSzabadsag.Text = "a";
            // 
            // lb_EvesSzabadsag
            // 
            lb_EvesSzabadsag.AutoSize = true;
            lb_EvesSzabadsag.Location = new Point(6, 30);
            lb_EvesSzabadsag.Name = "lb_EvesSzabadsag";
            lb_EvesSzabadsag.Size = new Size(90, 15);
            lb_EvesSzabadsag.TabIndex = 4;
            lb_EvesSzabadsag.Text = "Éves szabadság:";
            // 
            // tb_AlkEvesSzabadsag
            // 
            tb_AlkEvesSzabadsag.Location = new Point(121, 26);
            tb_AlkEvesSzabadsag.MaxLength = 2;
            tb_AlkEvesSzabadsag.Name = "tb_AlkEvesSzabadsag";
            tb_AlkEvesSzabadsag.Size = new Size(119, 23);
            tb_AlkEvesSzabadsag.TabIndex = 47;
            tb_AlkEvesSzabadsag.Visible = false;
            tb_AlkEvesSzabadsag.KeyPress += tb_AlkEvesSzabadsag_KeyPress;
            // 
            // btn_UjAlkalmazott
            // 
            btn_UjAlkalmazott.Location = new Point(12, 39);
            btn_UjAlkalmazott.Name = "btn_UjAlkalmazott";
            btn_UjAlkalmazott.Size = new Size(95, 23);
            btn_UjAlkalmazott.TabIndex = 4;
            btn_UjAlkalmazott.Text = "új alkalmazott";
            btn_UjAlkalmazott.UseVisualStyleBackColor = true;
            btn_UjAlkalmazott.Click += btn_UjAlkalmazott_Click;
            // 
            // btn_FelhasznalhatoSzabadsag
            // 
            btn_FelhasznalhatoSzabadsag.Location = new Point(12, 97);
            btn_FelhasznalhatoSzabadsag.Name = "btn_FelhasznalhatoSzabadsag";
            btn_FelhasznalhatoSzabadsag.Size = new Size(95, 39);
            btn_FelhasznalhatoSzabadsag.TabIndex = 5;
            btn_FelhasznalhatoSzabadsag.Text = "felhasználható szabadság";
            btn_FelhasznalhatoSzabadsag.UseVisualStyleBackColor = true;
            btn_FelhasznalhatoSzabadsag.Click += btn_FelhasznalhatoSzabadsag_Click;
            // 
            // btn_JelszoReset
            // 
            btn_JelszoReset.Location = new Point(12, 142);
            btn_JelszoReset.Name = "btn_JelszoReset";
            btn_JelszoReset.Size = new Size(95, 23);
            btn_JelszoReset.TabIndex = 6;
            btn_JelszoReset.Text = "jelszó reset";
            btn_JelszoReset.UseVisualStyleBackColor = true;
            btn_JelszoReset.Click += btn_JelszoReset_Click;
            // 
            // btn_MunkaidoJovahagyas
            // 
            btn_MunkaidoJovahagyas.Location = new Point(12, 206);
            btn_MunkaidoJovahagyas.Name = "btn_MunkaidoJovahagyas";
            btn_MunkaidoJovahagyas.Size = new Size(95, 39);
            btn_MunkaidoJovahagyas.TabIndex = 7;
            btn_MunkaidoJovahagyas.Text = "munkaidő jóváhagyás";
            btn_MunkaidoJovahagyas.UseVisualStyleBackColor = true;
            btn_MunkaidoJovahagyas.Click += btn_MunkaidoJovahagyas_Click;
            // 
            // btn_IgenylesJovahagyas
            // 
            btn_IgenylesJovahagyas.Location = new Point(12, 251);
            btn_IgenylesJovahagyas.Name = "btn_IgenylesJovahagyas";
            btn_IgenylesJovahagyas.Size = new Size(95, 39);
            btn_IgenylesJovahagyas.TabIndex = 8;
            btn_IgenylesJovahagyas.Text = "igénylés jóváhagyás";
            btn_IgenylesJovahagyas.UseVisualStyleBackColor = true;
            btn_IgenylesJovahagyas.Click += btn_IgenylesJovahagyas_Click;
            // 
            // frm_Foablak
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1127, 729);
            Controls.Add(btn_IgenylesJovahagyas);
            Controls.Add(btn_MunkaidoJovahagyas);
            Controls.Add(btn_JelszoReset);
            Controls.Add(btn_FelhasznalhatoSzabadsag);
            Controls.Add(btn_UjAlkalmazott);
            Controls.Add(grpb_AlkalmazottAdatai);
            Controls.Add(dgv_Alkalmazottak);
            Controls.Add(ms_Menusor);
            MainMenuStrip = ms_Menusor;
            Name = "frm_Foablak";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Munkaidő nyilvántartó";
            Shown += frm_Foablak_Shown;
            ((System.ComponentModel.ISupportInitialize)dgv_Alkalmazottak).EndInit();
            ms_Menusor.ResumeLayout(false);
            ms_Menusor.PerformLayout();
            grpb_AlkalmazottAdatai.ResumeLayout(false);
            grpb_AlkalmazottAdatai.PerformLayout();
            grpb_Munkaviszony.ResumeLayout(false);
            grpb_Munkaviszony.PerformLayout();
            grpb_Munkarend.ResumeLayout(false);
            grpb_Munkarend.PerformLayout();
            grpb_AlkalmazottLakcim.ResumeLayout(false);
            grpb_AlkalmazottLakcim.PerformLayout();
            grpb_Szabadsag.ResumeLayout(false);
            grpb_Szabadsag.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgv_Alkalmazottak;
        private MenuStrip ms_Menusor;
        private ToolStripMenuItem tsmi_Program;
        private ToolStripMenuItem tsmi_KilepesAProgrambol;
        private Label lb_beosztas;
        private GroupBox grpb_AlkalmazottAdatai;
        private Label lb_AlkBeosztas;
        private Label lb_AlkSzuletesiIdo;
        private Label lb_SzuletesiIdo;
        private Label lb_AlkSzuletesiHely;
        private Label lb_SzuletesiHely;
        private Label lb_AlkSzuletesiNev;
        private Label lb_SzuletesiNev;
        private GroupBox grpb_AlkalmazottLakcim;
        private Label lb_AlkIranyitoszam;
        private Label lb_Iranyitoszam;
        private Label lb_AlkCim;
        private Label lb_Cim;
        private Label lb_AlkTelepulesNeve;
        private Label lb_TelepulesNeve;
        private Label lb_AlkAnyjaNeve;
        private Label lb_AnyjaNeve;
        private GroupBox grpb_Munkarend;
        private Label lb_AlkEbedszunetKezdete;
        private Label lb_EbedszunetKezdete;
        private Label lb_AlkMunkaidoVege;
        private Label lb_MunkaidoVege;
        private Label lb_AlkMunkaidoKezdete;
        private Label lb_MunkaidoKezdete;
        private Label lb_AdoazonositoJel;
        private Label lb_AlkAdoazonositoJel;
        private Label lb_email;
        private Label lb_AlkEmail;
        private Label lb_AlkEbedszunetVege;
        private Label lb_EbedszunetVege;
        private Label lb_HomeOfficeLehetoseg;
        private Label lb_AlkHomeOfficeLehetoseg;
        private GroupBox grpb_Munkaviszony;
        private Label lb_AlkMunkaviszonyVege;
        private Label lb_MunkaviszonyVege;
        private Label lb_AlkMunkaviszonyKezdete;
        private Label lb_MunkaviszonyKezdete;
        private Label lb_Vezeto;
        private Label lb_AlkVezeto;
        private Label lb_Engedelyezo;
        private Label lb_AlkEngedelyezo;
        private Label lb_Adminisztrator;
        private Label lb_AlkAdminisztrator;
        private Button btn_AlkalmazottAdatainakModositasa;
        private Button btn_UjAlkalmazott;
        private Button btn_MunkaviszonyModositasa;
        private Button btn_MunkaidoModositas;
        private Button btn_LakcimModositasa;
        private TextBox tb_AlkSzuletesiHely;
        private TextBox tb_AlkSzuletesiNev;
        private TextBox tb_AlkAnyjaNeve;
        private DateTimePicker dtp_AlkSzuletesiIdo;
        private Button btn_AlkalmazottAdatainakModositasaMegsem;
        private Button btn_AlkalmazottAdatainakModositasaMentes;
        private TextBox tb_AlkIranyitoszam;
        private TextBox tb_AlkCim;
        private TextBox tb_AlkTelepulesNeve;
        private Button btn_LakcimModositasaMegsem;
        private Button btn_LakcimModositasaMentes;
        private DateTimePicker dtp_AlkMunkaviszonyKezdete;
        private DateTimePicker dtp_AlkMunkaviszonyVege;
        private Button btn_MunkaviszonyModositasaMegsem;
        private Button btn_MunkaviszonyModositasaMentes;
        private Button btn_MunkaidoModositasMegsem;
        private Button btn_MunkaidoModositasMentes;
        private ComboBox cb_AlkMunkaidoKezdete;
        private ComboBox cb_AlkMunkaidoVege;
        private ComboBox cb_AlkEbedidoKezdete;
        private ComboBox cb_AlkEbedidoVege;
        private TextBox tb_AlkBeosztas;
        private TextBox tb_AlkEmail;
        private TextBox tb_AlkAdoazonositoJel;
        private ComboBox cb_AlkEngedelyezo;
        private ComboBox cb_AlkVezeto;
        private ComboBox cb_AlkHomeOfficeLehetoseg;
        private GroupBox grpb_Szabadsag;
        private Button btn_SzabadsagModositasMegsem;
        private Button btn_SzabadsagModositasMentes;
        private Button btn_SzabadsagModositas;
        private Label lb_AlkEvesSzabadsag;
        private Label lb_EvesSzabadsag;
        private TextBox tb_AlkEvesSzabadsag;
        private Button btn_FelhasznalhatoSzabadsag;
        private Button btn_JelszoReset;
        private Button btn_MunkaidoJovahagyas;
        private Button btn_IgenylesJovahagyas;
    }
}