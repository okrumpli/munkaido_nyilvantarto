﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace munkaido_nyilvantarto
{
    public partial class frm_IgenylesJovahagyas : Form
    {
        int igenyles_azonosito;
        public frm_IgenylesJovahagyas()
        {
            InitializeComponent();
        }

        private void frm_IgenylesJovahagyas_Shown(object sender, EventArgs e)
        {
            frissit();
        }

        private void frissit()
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                var dt = new DataTable();
                String sql = "call osszes_jovahagyando_igenyles();";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                var da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dgv_Igenylesek.DataSource = dt;
                dgv_Igenylesek.Columns["igenyles_azonosito"].Visible = false;
                dgv_Igenylesek.Columns["alkalmazott_azonosito"].Visible = false;
                dgv_Igenylesek.Columns["eves_munkaido_naptar_azonosito"].Visible = false;
                dgv_Igenylesek.Columns["szuletesi_nev"].HeaderText = "Születési név";
                dgv_Igenylesek.Columns["datum"].HeaderText = "Dátum";
                dgv_Igenylesek.Columns["jovahagyva"].HeaderText = "Jóváhagyva";
                dgv_Igenylesek.Columns["tipus"].HeaderText = "Típus";
            }
        }

        private void dgv_Igenylesek_SelectionChanged(object sender, EventArgs e)
        {
            if (dgv_Igenylesek.SelectedRows.Count > 0)
            {
                igenyles_azonosito = Convert.ToInt32(dgv_Igenylesek.SelectedRows[0].Cells["igenyles_azonosito"].Value);
            }
        }

        private void btn_Bezar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Jovahagyas_Click(object sender, EventArgs e)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "igenyles_kezelese";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("p_igenyles_azonosito", igenyles_azonosito);
                cmd.Parameters.AddWithValue("p_dontes", "I");
                cmd.ExecuteNonQuery();
            }
            frissit();
        }

        private void btn_Elutasitas_Click(object sender, EventArgs e)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "igenyles_kezelese";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("p_igenyles_azonosito", igenyles_azonosito);
                cmd.Parameters.AddWithValue("p_dontes", "E");
                cmd.ExecuteNonQuery();
            }
            frissit();
        }
    }
}
