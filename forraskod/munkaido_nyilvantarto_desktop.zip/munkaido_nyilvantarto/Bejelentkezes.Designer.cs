﻿
namespace munkaido_nyilvantarto
{
    partial class frm_Bejelentkezes
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lb_Bejelentkezes = new Label();
            lb_Jelszo = new Label();
            tb_Bejelentkezes = new TextBox();
            tb_Jelszo = new TextBox();
            btn_Bejelentkezes = new Button();
            btn_Kilepes = new Button();
            lb_BejelentkezesiHiba = new Label();
            SuspendLayout();
            // 
            // lb_Bejelentkezes
            // 
            lb_Bejelentkezes.AutoSize = true;
            lb_Bejelentkezes.Location = new Point(41, 59);
            lb_Bejelentkezes.Name = "lb_Bejelentkezes";
            lb_Bejelentkezes.Size = new Size(122, 15);
            lb_Bejelentkezes.TabIndex = 0;
            lb_Bejelentkezes.Text = "E-mail/Adóazonosító:";
            // 
            // lb_Jelszo
            // 
            lb_Jelszo.AutoSize = true;
            lb_Jelszo.Location = new Point(41, 101);
            lb_Jelszo.Name = "lb_Jelszo";
            lb_Jelszo.Size = new Size(40, 15);
            lb_Jelszo.TabIndex = 1;
            lb_Jelszo.Text = "Jelszó:";
            // 
            // tb_Bejelentkezes
            // 
            tb_Bejelentkezes.Location = new Point(169, 56);
            tb_Bejelentkezes.Name = "tb_Bejelentkezes";
            tb_Bejelentkezes.Size = new Size(206, 23);
            tb_Bejelentkezes.TabIndex = 2;
            // 
            // tb_Jelszo
            // 
            tb_Jelszo.Location = new Point(169, 98);
            tb_Jelszo.Name = "tb_Jelszo";
            tb_Jelszo.PasswordChar = '*';
            tb_Jelszo.Size = new Size(206, 23);
            tb_Jelszo.TabIndex = 3;
            tb_Jelszo.KeyDown += tb_Jelszo_KeyDown;
            // 
            // btn_Bejelentkezes
            // 
            btn_Bejelentkezes.Location = new Point(77, 149);
            btn_Bejelentkezes.Name = "btn_Bejelentkezes";
            btn_Bejelentkezes.Size = new Size(100, 23);
            btn_Bejelentkezes.TabIndex = 4;
            btn_Bejelentkezes.Text = "Bejelentkezés";
            btn_Bejelentkezes.UseVisualStyleBackColor = true;
            btn_Bejelentkezes.Click += btn_Bejelentkezes_Click;
            // 
            // btn_Kilepes
            // 
            btn_Kilepes.Location = new Point(248, 149);
            btn_Kilepes.Name = "btn_Kilepes";
            btn_Kilepes.Size = new Size(100, 23);
            btn_Kilepes.TabIndex = 5;
            btn_Kilepes.Text = "Kilépés";
            btn_Kilepes.UseVisualStyleBackColor = true;
            btn_Kilepes.Click += btn_Kilepes_Click;
            // 
            // lb_BejelentkezesiHiba
            // 
            lb_BejelentkezesiHiba.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            lb_BejelentkezesiHiba.AutoSize = true;
            lb_BejelentkezesiHiba.ForeColor = Color.Red;
            lb_BejelentkezesiHiba.Location = new Point(3, 21);
            lb_BejelentkezesiHiba.MinimumSize = new Size(430, 0);
            lb_BejelentkezesiHiba.Name = "lb_BejelentkezesiHiba";
            lb_BejelentkezesiHiba.Size = new Size(430, 15);
            lb_BejelentkezesiHiba.TabIndex = 6;
            lb_BejelentkezesiHiba.TextAlign = ContentAlignment.TopCenter;
            lb_BejelentkezesiHiba.Visible = false;
            // 
            // frm_Bejelentkezes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(437, 222);
            Controls.Add(lb_BejelentkezesiHiba);
            Controls.Add(btn_Kilepes);
            Controls.Add(btn_Bejelentkezes);
            Controls.Add(tb_Jelszo);
            Controls.Add(tb_Bejelentkezes);
            Controls.Add(lb_Jelszo);
            Controls.Add(lb_Bejelentkezes);
            Name = "frm_Bejelentkezes";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Munkaidő nyilvántartó (bejelentkezés)";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lb_Bejelentkezes;
        private Label lb_Jelszo;
        private TextBox tb_Bejelentkezes;
        private TextBox tb_Jelszo;
        private Button btn_Bejelentkezes;
        private Button btn_Kilepes;
        private Label lb_BejelentkezesiHiba;
    }
}
