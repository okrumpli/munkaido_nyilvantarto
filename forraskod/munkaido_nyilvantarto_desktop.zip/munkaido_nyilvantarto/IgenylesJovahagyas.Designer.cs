﻿namespace munkaido_nyilvantarto
{
    partial class frm_IgenylesJovahagyas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgv_Igenylesek = new DataGridView();
            btn_Jovahagyas = new Button();
            btn_Bezar = new Button();
            btn_Elutasitas = new Button();
            ((System.ComponentModel.ISupportInitialize)dgv_Igenylesek).BeginInit();
            SuspendLayout();
            // 
            // dgv_Igenylesek
            // 
            dgv_Igenylesek.AllowUserToAddRows = false;
            dgv_Igenylesek.AllowUserToDeleteRows = false;
            dgv_Igenylesek.AllowUserToResizeColumns = false;
            dgv_Igenylesek.AllowUserToResizeRows = false;
            dgv_Igenylesek.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_Igenylesek.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Igenylesek.Location = new Point(12, 12);
            dgv_Igenylesek.MultiSelect = false;
            dgv_Igenylesek.Name = "dgv_Igenylesek";
            dgv_Igenylesek.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv_Igenylesek.Size = new Size(1102, 434);
            dgv_Igenylesek.TabIndex = 2;
            dgv_Igenylesek.SelectionChanged += dgv_Igenylesek_SelectionChanged;
            // 
            // btn_Jovahagyas
            // 
            btn_Jovahagyas.Location = new Point(25, 464);
            btn_Jovahagyas.Name = "btn_Jovahagyas";
            btn_Jovahagyas.Size = new Size(75, 23);
            btn_Jovahagyas.TabIndex = 5;
            btn_Jovahagyas.Text = "Jóváhagyás";
            btn_Jovahagyas.UseVisualStyleBackColor = true;
            btn_Jovahagyas.Click += btn_Jovahagyas_Click;
            // 
            // btn_Bezar
            // 
            btn_Bezar.Location = new Point(1037, 492);
            btn_Bezar.Name = "btn_Bezar";
            btn_Bezar.Size = new Size(75, 23);
            btn_Bezar.TabIndex = 4;
            btn_Bezar.Text = "Bezárás";
            btn_Bezar.UseVisualStyleBackColor = true;
            btn_Bezar.Click += btn_Bezar_Click;
            // 
            // btn_Elutasitas
            // 
            btn_Elutasitas.Location = new Point(106, 464);
            btn_Elutasitas.Name = "btn_Elutasitas";
            btn_Elutasitas.Size = new Size(75, 23);
            btn_Elutasitas.TabIndex = 6;
            btn_Elutasitas.Text = "Elutasítás";
            btn_Elutasitas.UseVisualStyleBackColor = true;
            btn_Elutasitas.Click += btn_Elutasitas_Click;
            // 
            // frm_IgenylesJovahagyas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1124, 527);
            Controls.Add(btn_Elutasitas);
            Controls.Add(btn_Jovahagyas);
            Controls.Add(btn_Bezar);
            Controls.Add(dgv_Igenylesek);
            Name = "frm_IgenylesJovahagyas";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Igénylések kezelése";
            Shown += frm_IgenylesJovahagyas_Shown;
            ((System.ComponentModel.ISupportInitialize)dgv_Igenylesek).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgv_Igenylesek;
        private Button btn_Jovahagyas;
        private Button btn_Bezar;
        private Button btn_Elutasitas;
    }
}