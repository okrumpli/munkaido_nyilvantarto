namespace munkaido_nyilvantarto
{
    internal static class Program
    {
        public static string constr = "This is a global string.";

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            constr = String.Format("Server={0};User ID={1};Password={2};Database={3}", "127.0.0.1", "root", "", "munkaido");


            Application.Run(new frm_Bejelentkezes());
        }
    }
}