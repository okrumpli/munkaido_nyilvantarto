﻿namespace munkaido_nyilvantarto
{
    partial class frm_UjAlkalmazott
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpb_AlkalmazottAdatai = new GroupBox();
            cb_Adminisztrator = new ComboBox();
            lb_Engedelyezo = new Label();
            lb_Adminisztrator = new Label();
            lb_HomeOfficeLehetoseg = new Label();
            grpb_Munkaviszony = new GroupBox();
            lb_MunkaviszonyVege = new Label();
            lb_MunkaviszonyKezdete = new Label();
            dtp_AlkMunkaviszonyKezdete = new DateTimePicker();
            dtp_AlkMunkaviszonyVege = new DateTimePicker();
            lb_Vezeto = new Label();
            grpb_Munkarend = new GroupBox();
            lb_EbedszunetVege = new Label();
            lb_EbedszunetKezdete = new Label();
            lb_MunkaidoVege = new Label();
            lb_MunkaidoKezdete = new Label();
            cb_AlkMunkaidoKezdete = new ComboBox();
            cb_AlkMunkaidoVege = new ComboBox();
            cb_AlkEbedidoKezdete = new ComboBox();
            cb_AlkEbedidoVege = new ComboBox();
            lb_AdoazonositoJel = new Label();
            lb_email = new Label();
            lb_AnyjaNeve = new Label();
            grpb_AlkalmazottLakcim = new GroupBox();
            lb_Iranyitoszam = new Label();
            lb_Cim = new Label();
            lb_TelepulesNeve = new Label();
            tb_AlkIranyitoszam = new TextBox();
            tb_AlkCim = new TextBox();
            tb_AlkTelepulesNeve = new TextBox();
            lb_beosztas = new Label();
            lb_SzuletesiIdo = new Label();
            lb_SzuletesiHely = new Label();
            lb_SzuletesiNev = new Label();
            dtp_AlkSzuletesiIdo = new DateTimePicker();
            tb_AlkAnyjaNeve = new TextBox();
            tb_AlkSzuletesiHely = new TextBox();
            tb_AlkSzuletesiNev = new TextBox();
            tb_AlkBeosztas = new TextBox();
            tb_AlkEmail = new TextBox();
            tb_AlkAdoazonositoJel = new TextBox();
            cb_AlkEngedelyezo = new ComboBox();
            cb_AlkVezeto = new ComboBox();
            cb_AlkHomeOfficeLehetoseg = new ComboBox();
            btn_AlkalmazottAdatainakModositasaMegsem = new Button();
            btn_AlkalmazottAdatainakModositasaMentes = new Button();
            grpb_AlkalmazottAdatai.SuspendLayout();
            grpb_Munkaviszony.SuspendLayout();
            grpb_Munkarend.SuspendLayout();
            grpb_AlkalmazottLakcim.SuspendLayout();
            SuspendLayout();
            // 
            // grpb_AlkalmazottAdatai
            // 
            grpb_AlkalmazottAdatai.Controls.Add(cb_Adminisztrator);
            grpb_AlkalmazottAdatai.Controls.Add(lb_Engedelyezo);
            grpb_AlkalmazottAdatai.Controls.Add(lb_Adminisztrator);
            grpb_AlkalmazottAdatai.Controls.Add(lb_HomeOfficeLehetoseg);
            grpb_AlkalmazottAdatai.Controls.Add(grpb_Munkaviszony);
            grpb_AlkalmazottAdatai.Controls.Add(lb_Vezeto);
            grpb_AlkalmazottAdatai.Controls.Add(grpb_Munkarend);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AdoazonositoJel);
            grpb_AlkalmazottAdatai.Controls.Add(lb_email);
            grpb_AlkalmazottAdatai.Controls.Add(lb_AnyjaNeve);
            grpb_AlkalmazottAdatai.Controls.Add(grpb_AlkalmazottLakcim);
            grpb_AlkalmazottAdatai.Controls.Add(lb_beosztas);
            grpb_AlkalmazottAdatai.Controls.Add(lb_SzuletesiIdo);
            grpb_AlkalmazottAdatai.Controls.Add(lb_SzuletesiHely);
            grpb_AlkalmazottAdatai.Controls.Add(lb_SzuletesiNev);
            grpb_AlkalmazottAdatai.Controls.Add(dtp_AlkSzuletesiIdo);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkAnyjaNeve);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkSzuletesiHely);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkSzuletesiNev);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkBeosztas);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkEmail);
            grpb_AlkalmazottAdatai.Controls.Add(tb_AlkAdoazonositoJel);
            grpb_AlkalmazottAdatai.Controls.Add(cb_AlkEngedelyezo);
            grpb_AlkalmazottAdatai.Controls.Add(cb_AlkVezeto);
            grpb_AlkalmazottAdatai.Controls.Add(cb_AlkHomeOfficeLehetoseg);
            grpb_AlkalmazottAdatai.Location = new Point(12, 12);
            grpb_AlkalmazottAdatai.Name = "grpb_AlkalmazottAdatai";
            grpb_AlkalmazottAdatai.Size = new Size(571, 583);
            grpb_AlkalmazottAdatai.TabIndex = 4;
            grpb_AlkalmazottAdatai.TabStop = false;
            grpb_AlkalmazottAdatai.Text = "Alkalmazott adatai";
            // 
            // cb_Adminisztrator
            // 
            cb_Adminisztrator.FormattingEnabled = true;
            cb_Adminisztrator.Items.AddRange(new object[] { "I", "N" });
            cb_Adminisztrator.Location = new Point(100, 547);
            cb_Adminisztrator.Name = "cb_Adminisztrator";
            cb_Adminisztrator.Size = new Size(121, 23);
            cb_Adminisztrator.TabIndex = 20;
            // 
            // lb_Engedelyezo
            // 
            lb_Engedelyezo.AutoSize = true;
            lb_Engedelyezo.Location = new Point(301, 294);
            lb_Engedelyezo.Name = "lb_Engedelyezo";
            lb_Engedelyezo.Size = new Size(104, 15);
            lb_Engedelyezo.TabIndex = 23;
            lb_Engedelyezo.Text = "Engedélyező neve:";
            // 
            // lb_Adminisztrator
            // 
            lb_Adminisztrator.AutoSize = true;
            lb_Adminisztrator.Location = new Point(6, 552);
            lb_Adminisztrator.Name = "lb_Adminisztrator";
            lb_Adminisztrator.Size = new Size(88, 15);
            lb_Adminisztrator.TabIndex = 21;
            lb_Adminisztrator.Text = "Adminisztrátor:";
            // 
            // lb_HomeOfficeLehetoseg
            // 
            lb_HomeOfficeLehetoseg.AutoSize = true;
            lb_HomeOfficeLehetoseg.Location = new Point(301, 268);
            lb_HomeOfficeLehetoseg.Name = "lb_HomeOfficeLehetoseg";
            lb_HomeOfficeLehetoseg.Size = new Size(78, 15);
            lb_HomeOfficeLehetoseg.TabIndex = 19;
            lb_HomeOfficeLehetoseg.Text = "Home Office:";
            // 
            // grpb_Munkaviszony
            // 
            grpb_Munkaviszony.Controls.Add(lb_MunkaviszonyVege);
            grpb_Munkaviszony.Controls.Add(lb_MunkaviszonyKezdete);
            grpb_Munkaviszony.Controls.Add(dtp_AlkMunkaviszonyKezdete);
            grpb_Munkaviszony.Controls.Add(dtp_AlkMunkaviszonyVege);
            grpb_Munkaviszony.Location = new Point(6, 344);
            grpb_Munkaviszony.Name = "grpb_Munkaviszony";
            grpb_Munkaviszony.Size = new Size(559, 89);
            grpb_Munkaviszony.TabIndex = 17;
            grpb_Munkaviszony.TabStop = false;
            grpb_Munkaviszony.Text = "Munkaviszony";
            // 
            // lb_MunkaviszonyVege
            // 
            lb_MunkaviszonyVege.AutoSize = true;
            lb_MunkaviszonyVege.Location = new Point(295, 30);
            lb_MunkaviszonyVege.Name = "lb_MunkaviszonyVege";
            lb_MunkaviszonyVege.Size = new Size(114, 15);
            lb_MunkaviszonyVege.TabIndex = 6;
            lb_MunkaviszonyVege.Text = "Munkaviszony vége:";
            // 
            // lb_MunkaviszonyKezdete
            // 
            lb_MunkaviszonyKezdete.AutoSize = true;
            lb_MunkaviszonyKezdete.Location = new Point(6, 30);
            lb_MunkaviszonyKezdete.Name = "lb_MunkaviszonyKezdete";
            lb_MunkaviszonyKezdete.Size = new Size(129, 15);
            lb_MunkaviszonyKezdete.TabIndex = 4;
            lb_MunkaviszonyKezdete.Text = "Munkaviszony kezdete:";
            // 
            // dtp_AlkMunkaviszonyKezdete
            // 
            dtp_AlkMunkaviszonyKezdete.Format = DateTimePickerFormat.Short;
            dtp_AlkMunkaviszonyKezdete.Location = new Point(137, 26);
            dtp_AlkMunkaviszonyKezdete.Name = "dtp_AlkMunkaviszonyKezdete";
            dtp_AlkMunkaviszonyKezdete.Size = new Size(140, 23);
            dtp_AlkMunkaviszonyKezdete.TabIndex = 14;
            // 
            // dtp_AlkMunkaviszonyVege
            // 
            dtp_AlkMunkaviszonyVege.Checked = false;
            dtp_AlkMunkaviszonyVege.Format = DateTimePickerFormat.Short;
            dtp_AlkMunkaviszonyVege.Location = new Point(410, 26);
            dtp_AlkMunkaviszonyVege.Name = "dtp_AlkMunkaviszonyVege";
            dtp_AlkMunkaviszonyVege.ShowCheckBox = true;
            dtp_AlkMunkaviszonyVege.Size = new Size(140, 23);
            dtp_AlkMunkaviszonyVege.TabIndex = 15;
            // 
            // lb_Vezeto
            // 
            lb_Vezeto.AutoSize = true;
            lb_Vezeto.Location = new Point(301, 242);
            lb_Vezeto.Name = "lb_Vezeto";
            lb_Vezeto.Size = new Size(44, 15);
            lb_Vezeto.TabIndex = 17;
            lb_Vezeto.Text = "Vezető:";
            // 
            // grpb_Munkarend
            // 
            grpb_Munkarend.Controls.Add(lb_EbedszunetVege);
            grpb_Munkarend.Controls.Add(lb_EbedszunetKezdete);
            grpb_Munkarend.Controls.Add(lb_MunkaidoVege);
            grpb_Munkarend.Controls.Add(lb_MunkaidoKezdete);
            grpb_Munkarend.Controls.Add(cb_AlkMunkaidoKezdete);
            grpb_Munkarend.Controls.Add(cb_AlkMunkaidoVege);
            grpb_Munkarend.Controls.Add(cb_AlkEbedidoKezdete);
            grpb_Munkarend.Controls.Add(cb_AlkEbedidoVege);
            grpb_Munkarend.Location = new Point(6, 436);
            grpb_Munkarend.Name = "grpb_Munkarend";
            grpb_Munkarend.Size = new Size(559, 105);
            grpb_Munkarend.TabIndex = 16;
            grpb_Munkarend.TabStop = false;
            grpb_Munkarend.Text = "Munkaidő";
            // 
            // lb_EbedszunetVege
            // 
            lb_EbedszunetVege.AutoSize = true;
            lb_EbedszunetVege.Location = new Point(295, 54);
            lb_EbedszunetVege.Name = "lb_EbedszunetVege";
            lb_EbedszunetVege.Size = new Size(98, 15);
            lb_EbedszunetVege.TabIndex = 10;
            lb_EbedszunetVege.Text = "Ebédszünet vége:";
            // 
            // lb_EbedszunetKezdete
            // 
            lb_EbedszunetKezdete.AutoSize = true;
            lb_EbedszunetKezdete.Location = new Point(295, 30);
            lb_EbedszunetKezdete.Name = "lb_EbedszunetKezdete";
            lb_EbedszunetKezdete.Size = new Size(113, 15);
            lb_EbedszunetKezdete.TabIndex = 8;
            lb_EbedszunetKezdete.Text = "Ebédszünet kezdete:";
            // 
            // lb_MunkaidoVege
            // 
            lb_MunkaidoVege.AutoSize = true;
            lb_MunkaidoVege.Location = new Point(6, 54);
            lb_MunkaidoVege.Name = "lb_MunkaidoVege";
            lb_MunkaidoVege.Size = new Size(92, 15);
            lb_MunkaidoVege.TabIndex = 6;
            lb_MunkaidoVege.Text = "Munkaidő vége:";
            // 
            // lb_MunkaidoKezdete
            // 
            lb_MunkaidoKezdete.AutoSize = true;
            lb_MunkaidoKezdete.Location = new Point(6, 30);
            lb_MunkaidoKezdete.Name = "lb_MunkaidoKezdete";
            lb_MunkaidoKezdete.Size = new Size(107, 15);
            lb_MunkaidoKezdete.TabIndex = 4;
            lb_MunkaidoKezdete.Text = "Munkaidő kezdete:";
            // 
            // cb_AlkMunkaidoKezdete
            // 
            cb_AlkMunkaidoKezdete.FormattingEnabled = true;
            cb_AlkMunkaidoKezdete.Items.AddRange(new object[] { "00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30" });
            cb_AlkMunkaidoKezdete.Location = new Point(119, 26);
            cb_AlkMunkaidoKezdete.Name = "cb_AlkMunkaidoKezdete";
            cb_AlkMunkaidoKezdete.Size = new Size(121, 23);
            cb_AlkMunkaidoKezdete.TabIndex = 16;
            // 
            // cb_AlkMunkaidoVege
            // 
            cb_AlkMunkaidoVege.FormattingEnabled = true;
            cb_AlkMunkaidoVege.Items.AddRange(new object[] { "00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30" });
            cb_AlkMunkaidoVege.Location = new Point(119, 50);
            cb_AlkMunkaidoVege.Name = "cb_AlkMunkaidoVege";
            cb_AlkMunkaidoVege.Size = new Size(121, 23);
            cb_AlkMunkaidoVege.TabIndex = 17;
            // 
            // cb_AlkEbedidoKezdete
            // 
            cb_AlkEbedidoKezdete.FormattingEnabled = true;
            cb_AlkEbedidoKezdete.Items.AddRange(new object[] { "00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30" });
            cb_AlkEbedidoKezdete.Location = new Point(408, 26);
            cb_AlkEbedidoKezdete.Name = "cb_AlkEbedidoKezdete";
            cb_AlkEbedidoKezdete.Size = new Size(121, 23);
            cb_AlkEbedidoKezdete.TabIndex = 18;
            // 
            // cb_AlkEbedidoVege
            // 
            cb_AlkEbedidoVege.FormattingEnabled = true;
            cb_AlkEbedidoVege.Items.AddRange(new object[] { "00:00", "00:30", "01:00", "01:30", "02:00", "02:30", "03:00", "03:30", "04:00", "04:30", "05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30", "23:00", "23:30" });
            cb_AlkEbedidoVege.Location = new Point(408, 50);
            cb_AlkEbedidoVege.Name = "cb_AlkEbedidoVege";
            cb_AlkEbedidoVege.Size = new Size(121, 23);
            cb_AlkEbedidoVege.TabIndex = 19;
            // 
            // lb_AdoazonositoJel
            // 
            lb_AdoazonositoJel.AutoSize = true;
            lb_AdoazonositoJel.Location = new Point(6, 294);
            lb_AdoazonositoJel.Name = "lb_AdoazonositoJel";
            lb_AdoazonositoJel.Size = new Size(46, 15);
            lb_AdoazonositoJel.TabIndex = 14;
            lb_AdoazonositoJel.Text = "Adóaz.:";
            // 
            // lb_email
            // 
            lb_email.AutoSize = true;
            lb_email.Location = new Point(6, 268);
            lb_email.Name = "lb_email";
            lb_email.Size = new Size(44, 15);
            lb_email.TabIndex = 12;
            lb_email.Text = "E-mail:";
            // 
            // lb_AnyjaNeve
            // 
            lb_AnyjaNeve.AutoSize = true;
            lb_AnyjaNeve.Location = new Point(6, 92);
            lb_AnyjaNeve.Name = "lb_AnyjaNeve";
            lb_AnyjaNeve.Size = new Size(68, 15);
            lb_AnyjaNeve.TabIndex = 10;
            lb_AnyjaNeve.Text = "Anyja neve:";
            // 
            // grpb_AlkalmazottLakcim
            // 
            grpb_AlkalmazottLakcim.Controls.Add(lb_Iranyitoszam);
            grpb_AlkalmazottLakcim.Controls.Add(lb_Cim);
            grpb_AlkalmazottLakcim.Controls.Add(lb_TelepulesNeve);
            grpb_AlkalmazottLakcim.Controls.Add(tb_AlkIranyitoszam);
            grpb_AlkalmazottLakcim.Controls.Add(tb_AlkCim);
            grpb_AlkalmazottLakcim.Controls.Add(tb_AlkTelepulesNeve);
            grpb_AlkalmazottLakcim.Location = new Point(6, 126);
            grpb_AlkalmazottLakcim.Name = "grpb_AlkalmazottLakcim";
            grpb_AlkalmazottLakcim.Size = new Size(559, 104);
            grpb_AlkalmazottLakcim.TabIndex = 4;
            grpb_AlkalmazottLakcim.TabStop = false;
            grpb_AlkalmazottLakcim.Text = "Lakcím";
            // 
            // lb_Iranyitoszam
            // 
            lb_Iranyitoszam.AutoSize = true;
            lb_Iranyitoszam.Location = new Point(6, 78);
            lb_Iranyitoszam.Name = "lb_Iranyitoszam";
            lb_Iranyitoszam.Size = new Size(77, 15);
            lb_Iranyitoszam.TabIndex = 8;
            lb_Iranyitoszam.Text = "Irányítószám:";
            // 
            // lb_Cim
            // 
            lb_Cim.AutoSize = true;
            lb_Cim.Location = new Point(6, 54);
            lb_Cim.Name = "lb_Cim";
            lb_Cim.Size = new Size(32, 15);
            lb_Cim.TabIndex = 6;
            lb_Cim.Text = "Cím:";
            // 
            // lb_TelepulesNeve
            // 
            lb_TelepulesNeve.AutoSize = true;
            lb_TelepulesNeve.Location = new Point(6, 30);
            lb_TelepulesNeve.Name = "lb_TelepulesNeve";
            lb_TelepulesNeve.Size = new Size(58, 15);
            lb_TelepulesNeve.TabIndex = 4;
            lb_TelepulesNeve.Text = "Település:";
            // 
            // tb_AlkIranyitoszam
            // 
            tb_AlkIranyitoszam.Location = new Point(87, 73);
            tb_AlkIranyitoszam.MaxLength = 4;
            tb_AlkIranyitoszam.Name = "tb_AlkIranyitoszam";
            tb_AlkIranyitoszam.Size = new Size(262, 23);
            tb_AlkIranyitoszam.TabIndex = 7;
            tb_AlkIranyitoszam.KeyPress += tb_AlkIranyitoszam_KeyPress;
            // 
            // tb_AlkCim
            // 
            tb_AlkCim.Location = new Point(87, 49);
            tb_AlkCim.Name = "tb_AlkCim";
            tb_AlkCim.Size = new Size(262, 23);
            tb_AlkCim.TabIndex = 6;
            // 
            // tb_AlkTelepulesNeve
            // 
            tb_AlkTelepulesNeve.Location = new Point(87, 25);
            tb_AlkTelepulesNeve.Name = "tb_AlkTelepulesNeve";
            tb_AlkTelepulesNeve.Size = new Size(262, 23);
            tb_AlkTelepulesNeve.TabIndex = 5;
            // 
            // lb_beosztas
            // 
            lb_beosztas.AutoSize = true;
            lb_beosztas.Location = new Point(6, 242);
            lb_beosztas.Name = "lb_beosztas";
            lb_beosztas.Size = new Size(55, 15);
            lb_beosztas.TabIndex = 2;
            lb_beosztas.Text = "Beosztás:";
            // 
            // lb_SzuletesiIdo
            // 
            lb_SzuletesiIdo.AutoSize = true;
            lb_SzuletesiIdo.Location = new Point(6, 68);
            lb_SzuletesiIdo.Name = "lb_SzuletesiIdo";
            lb_SzuletesiIdo.Size = new Size(54, 15);
            lb_SzuletesiIdo.TabIndex = 8;
            lb_SzuletesiIdo.Text = "Szül. idő:";
            // 
            // lb_SzuletesiHely
            // 
            lb_SzuletesiHely.AutoSize = true;
            lb_SzuletesiHely.Location = new Point(6, 44);
            lb_SzuletesiHely.Name = "lb_SzuletesiHely";
            lb_SzuletesiHely.Size = new Size(59, 15);
            lb_SzuletesiHely.TabIndex = 6;
            lb_SzuletesiHely.Text = "Szül. hely:";
            // 
            // lb_SzuletesiNev
            // 
            lb_SzuletesiNev.AutoSize = true;
            lb_SzuletesiNev.Location = new Point(6, 20);
            lb_SzuletesiNev.Name = "lb_SzuletesiNev";
            lb_SzuletesiNev.Size = new Size(31, 15);
            lb_SzuletesiNev.TabIndex = 4;
            lb_SzuletesiNev.Text = "Név:";
            // 
            // dtp_AlkSzuletesiIdo
            // 
            dtp_AlkSzuletesiIdo.Format = DateTimePickerFormat.Short;
            dtp_AlkSzuletesiIdo.Location = new Point(74, 65);
            dtp_AlkSzuletesiIdo.Name = "dtp_AlkSzuletesiIdo";
            dtp_AlkSzuletesiIdo.Size = new Size(262, 23);
            dtp_AlkSzuletesiIdo.TabIndex = 3;
            // 
            // tb_AlkAnyjaNeve
            // 
            tb_AlkAnyjaNeve.Location = new Point(74, 89);
            tb_AlkAnyjaNeve.Name = "tb_AlkAnyjaNeve";
            tb_AlkAnyjaNeve.Size = new Size(262, 23);
            tb_AlkAnyjaNeve.TabIndex = 4;
            // 
            // tb_AlkSzuletesiHely
            // 
            tb_AlkSzuletesiHely.Location = new Point(74, 41);
            tb_AlkSzuletesiHely.Name = "tb_AlkSzuletesiHely";
            tb_AlkSzuletesiHely.Size = new Size(262, 23);
            tb_AlkSzuletesiHely.TabIndex = 2;
            // 
            // tb_AlkSzuletesiNev
            // 
            tb_AlkSzuletesiNev.Location = new Point(74, 17);
            tb_AlkSzuletesiNev.Name = "tb_AlkSzuletesiNev";
            tb_AlkSzuletesiNev.Size = new Size(262, 23);
            tb_AlkSzuletesiNev.TabIndex = 1;
            // 
            // tb_AlkBeosztas
            // 
            tb_AlkBeosztas.Location = new Point(74, 239);
            tb_AlkBeosztas.Name = "tb_AlkBeosztas";
            tb_AlkBeosztas.Size = new Size(189, 23);
            tb_AlkBeosztas.TabIndex = 8;
            // 
            // tb_AlkEmail
            // 
            tb_AlkEmail.Location = new Point(74, 265);
            tb_AlkEmail.Name = "tb_AlkEmail";
            tb_AlkEmail.Size = new Size(189, 23);
            tb_AlkEmail.TabIndex = 9;
            // 
            // tb_AlkAdoazonositoJel
            // 
            tb_AlkAdoazonositoJel.Location = new Point(74, 291);
            tb_AlkAdoazonositoJel.Name = "tb_AlkAdoazonositoJel";
            tb_AlkAdoazonositoJel.Size = new Size(189, 23);
            tb_AlkAdoazonositoJel.TabIndex = 10;
            // 
            // cb_AlkEngedelyezo
            // 
            cb_AlkEngedelyezo.FormattingEnabled = true;
            cb_AlkEngedelyezo.Location = new Point(414, 291);
            cb_AlkEngedelyezo.Name = "cb_AlkEngedelyezo";
            cb_AlkEngedelyezo.Size = new Size(121, 23);
            cb_AlkEngedelyezo.TabIndex = 13;
            // 
            // cb_AlkVezeto
            // 
            cb_AlkVezeto.FormattingEnabled = true;
            cb_AlkVezeto.Items.AddRange(new object[] { "I", "N" });
            cb_AlkVezeto.Location = new Point(414, 239);
            cb_AlkVezeto.Name = "cb_AlkVezeto";
            cb_AlkVezeto.Size = new Size(121, 23);
            cb_AlkVezeto.TabIndex = 11;
            // 
            // cb_AlkHomeOfficeLehetoseg
            // 
            cb_AlkHomeOfficeLehetoseg.FormattingEnabled = true;
            cb_AlkHomeOfficeLehetoseg.Items.AddRange(new object[] { "I", "N" });
            cb_AlkHomeOfficeLehetoseg.Location = new Point(414, 265);
            cb_AlkHomeOfficeLehetoseg.Name = "cb_AlkHomeOfficeLehetoseg";
            cb_AlkHomeOfficeLehetoseg.Size = new Size(121, 23);
            cb_AlkHomeOfficeLehetoseg.TabIndex = 12;
            // 
            // btn_AlkalmazottAdatainakModositasaMegsem
            // 
            btn_AlkalmazottAdatainakModositasaMegsem.Location = new Point(384, 613);
            btn_AlkalmazottAdatainakModositasaMegsem.Name = "btn_AlkalmazottAdatainakModositasaMegsem";
            btn_AlkalmazottAdatainakModositasaMegsem.Size = new Size(75, 23);
            btn_AlkalmazottAdatainakModositasaMegsem.TabIndex = 22;
            btn_AlkalmazottAdatainakModositasaMegsem.Text = "mégsem";
            btn_AlkalmazottAdatainakModositasaMegsem.UseVisualStyleBackColor = true;
            btn_AlkalmazottAdatainakModositasaMegsem.Click += btn_AlkalmazottAdatainakModositasaMegsem_Click;
            // 
            // btn_AlkalmazottAdatainakModositasaMentes
            // 
            btn_AlkalmazottAdatainakModositasaMentes.Location = new Point(112, 613);
            btn_AlkalmazottAdatainakModositasaMentes.Name = "btn_AlkalmazottAdatainakModositasaMentes";
            btn_AlkalmazottAdatainakModositasaMentes.Size = new Size(75, 23);
            btn_AlkalmazottAdatainakModositasaMentes.TabIndex = 21;
            btn_AlkalmazottAdatainakModositasaMentes.Text = "mentés";
            btn_AlkalmazottAdatainakModositasaMentes.UseVisualStyleBackColor = true;
            btn_AlkalmazottAdatainakModositasaMentes.Click += btn_AlkalmazottAdatainakModositasaMentes_Click;
            // 
            // frm_UjAlkalmazott
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(590, 658);
            Controls.Add(grpb_AlkalmazottAdatai);
            Controls.Add(btn_AlkalmazottAdatainakModositasaMegsem);
            Controls.Add(btn_AlkalmazottAdatainakModositasaMentes);
            Name = "frm_UjAlkalmazott";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Új alkalmazott felvitele";
            Shown += frm_UjAlkalmazott_Shown;
            grpb_AlkalmazottAdatai.ResumeLayout(false);
            grpb_AlkalmazottAdatai.PerformLayout();
            grpb_Munkaviszony.ResumeLayout(false);
            grpb_Munkaviszony.PerformLayout();
            grpb_Munkarend.ResumeLayout(false);
            grpb_Munkarend.PerformLayout();
            grpb_AlkalmazottLakcim.ResumeLayout(false);
            grpb_AlkalmazottLakcim.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grpb_AlkalmazottAdatai;
        private Button btn_AlkalmazottAdatainakModositasaMegsem;
        private Button btn_AlkalmazottAdatainakModositasaMentes;
        private Label lb_Engedelyezo;
        private Label lb_Adminisztrator;
        private Label lb_HomeOfficeLehetoseg;
        private GroupBox grpb_Munkaviszony;
        private Label lb_MunkaviszonyVege;
        private Label lb_MunkaviszonyKezdete;
        private DateTimePicker dtp_AlkMunkaviszonyKezdete;
        private DateTimePicker dtp_AlkMunkaviszonyVege;
        private Label lb_Vezeto;
        private GroupBox grpb_Munkarend;
        private Label lb_EbedszunetVege;
        private Label lb_EbedszunetKezdete;
        private Label lb_MunkaidoVege;
        private Label lb_MunkaidoKezdete;
        private ComboBox cb_AlkMunkaidoKezdete;
        private ComboBox cb_AlkMunkaidoVege;
        private ComboBox cb_AlkEbedidoKezdete;
        private ComboBox cb_AlkEbedidoVege;
        private Label lb_AdoazonositoJel;
        private Label lb_email;
        private Label lb_AnyjaNeve;
        private GroupBox grpb_AlkalmazottLakcim;
        private Label lb_Iranyitoszam;
        private Label lb_Cim;
        private Label lb_TelepulesNeve;
        private TextBox tb_AlkIranyitoszam;
        private TextBox tb_AlkCim;
        private TextBox tb_AlkTelepulesNeve;
        private Label lb_beosztas;
        private Label lb_SzuletesiIdo;
        private Label lb_SzuletesiHely;
        private Label lb_SzuletesiNev;
        private DateTimePicker dtp_AlkSzuletesiIdo;
        private TextBox tb_AlkAnyjaNeve;
        private TextBox tb_AlkSzuletesiHely;
        private TextBox tb_AlkSzuletesiNev;
        private TextBox tb_AlkBeosztas;
        private TextBox tb_AlkEmail;
        private TextBox tb_AlkAdoazonositoJel;
        private ComboBox cb_AlkEngedelyezo;
        private ComboBox cb_AlkVezeto;
        private ComboBox cb_AlkHomeOfficeLehetoseg;
        private ComboBox cb_Adminisztrator;
    }
}