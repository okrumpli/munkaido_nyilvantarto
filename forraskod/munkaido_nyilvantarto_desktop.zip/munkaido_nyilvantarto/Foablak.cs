﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace munkaido_nyilvantarto
{
    public partial class frm_Foablak : Form
    {
        int alkalmazott_azonosito;
        List<int> cb_AlkEngedelyezo_azonosito_lista;

        public frm_Foablak()
        {
            InitializeComponent();
            cb_AlkEngedelyezo_azonosito_lista = new List<int>();
        }

        private void tsmi_KilepesAProgrambol_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frm_Foablak_Shown(object sender, EventArgs e)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                var dt = new DataTable();
                String sql = "SELECT alkalmazott_azonosito, szuletesi_nev as \"Születési név\", email as \"E-mail\", adoazonosito_jel as \"Adóazonosító jel\" FROM alkalmazott;";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                var da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dgv_Alkalmazottak.DataSource = dt;
                dgv_Alkalmazottak.Columns["alkalmazott_azonosito"].Visible = false;
            }
        }

        private void dgv_Alkalmazottak_SelectionChanged(object sender, EventArgs e)
        {
            if (dgv_Alkalmazottak.SelectedRows.Count > 0)
            {
                using (var mc_mysqlcon = new MySqlConnection(Program.constr))
                {
                    alkalmazott_azonosito = Convert.ToInt32(dgv_Alkalmazottak.SelectedRows[0].Cells["alkalmazott_azonosito"].Value);
                    mc_mysqlcon.Open();
                    String sql = "SELECT * FROM alkalmazott WHERE alkalmazott_azonosito = @alkalmazott_azonosito;";
                    var cmd = new MySqlCommand(sql, mc_mysqlcon);
                    cmd.Parameters.AddWithValue("@alkalmazott_azonosito", alkalmazott_azonosito);
                    using (var reader = cmd.ExecuteReader())
                    {
                        reader.Read();
                        try
                        {
                            lb_AlkSzuletesiNev.Text = reader.GetString("szuletesi_nev");
                            lb_AlkSzuletesiHely.Text = reader.GetString("szuletesi_hely");
                            lb_AlkSzuletesiIdo.Text = reader.GetDateTime("szuletesi_ido").ToShortDateString();
                            lb_AlkAnyjaNeve.Text = reader.GetString("anyja_szuletesi_neve");
                            lb_AlkBeosztas.Text = reader.GetString("beosztas");
                            lb_AlkEmail.Text = reader.GetString("email");
                            lb_AlkAdoazonositoJel.Text = reader.GetString("adoazonosito_jel");
                            lb_AlkVezeto.Text = reader.GetString("vezeto");
                            lb_AlkHomeOfficeLehetoseg.Text = reader.GetString("homeoffice_lehetoseg");
                            lb_AlkMunkaviszonyKezdete.Text = reader.GetDateTime("belepes_datuma").ToShortDateString();
                            lb_AlkMunkaviszonyVege.Text = reader.IsDBNull("kilepes_datuma") ? "" : reader.GetDateTime("kilepes_datuma").ToShortDateString();
                            lb_AlkAdminisztrator.Text = reader.GetString("adminisztrator");

                            lb_AlkEngedelyezo.Text = reader.IsDBNull("engedelyezo") ? "" : engedelyezo_neve(reader.GetInt32("engedelyezo"));

                            lakcim_lekerdezese(alkalmazott_azonosito);
                            munkaido_lekerdezese(alkalmazott_azonosito);
                            szabadsag_lekerdezese(alkalmazott_azonosito, DateTime.Now.Year);
                            //lb_AlkMunkaidoKezdete.Text = reader.GetMySqlDateTime("")
                        }
                        catch (System.InvalidOperationException ex)
                        {
                            MessageBox.Show("Kérem, ellenőrizze, hogy jó alkalmazott_azonosito-t adott meg!");
                        }
                    }
                }
            }
        }

        private String engedelyezo_neve(int p_alkalmazott_azonosito)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "SELECT szuletesi_nev FROM alkalmazott WHERE alkalmazott_azonosito = @alkalmazott_azonosito;";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.Parameters.AddWithValue("@alkalmazott_azonosito", p_alkalmazott_azonosito);
                using (var reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    try
                    {
                        return reader.GetString("szuletesi_nev");
                    }
                    catch (System.InvalidOperationException ex)
                    {
                        return "";
                    }
                }
            }
        }


        private void munkaido_lekerdezese(int p_alkalmazott_azonosito)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "SELECT * FROM alkalmazotti_munkarend WHERE alkalmazott_azonosito = @alkalmazott_azonosito;";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.Parameters.AddWithValue("@alkalmazott_azonosito", p_alkalmazott_azonosito);
                using (var reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    try
                    {
                        lb_AlkMunkaidoKezdete.Text = reader.IsDBNull("munkaido_kezdete") ? "" : reader.GetTimeSpan("munkaido_kezdete").ToString(@"hh\:mm");
                        lb_AlkMunkaidoVege.Text = reader.IsDBNull("munkaido_vege") ? "" : reader.GetTimeSpan("munkaido_vege").ToString(@"hh\:mm");
                        lb_AlkEbedszunetKezdete.Text = reader.IsDBNull("ebedido_kezdete") ? "" : reader.GetTimeSpan("ebedido_kezdete").ToString(@"hh\:mm");
                        lb_AlkEbedszunetVege.Text = reader.IsDBNull("ebedido_vege") ? "" : reader.GetTimeSpan("ebedido_vege").ToString(@"hh\:mm");
                    }
                    catch (System.InvalidOperationException ex)
                    {
                        lb_AlkMunkaidoKezdete.Text = "";
                        lb_AlkMunkaidoVege.Text = "";
                        lb_AlkEbedszunetKezdete.Text = "";
                        lb_AlkEbedszunetVege.Text = "";
                    }
                }
            }
        }

        private void lakcim_lekerdezese(int p_alkalmazott_azonosito)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "SELECT * FROM lakcim WHERE alkalmazott_azonosito = @alkalmazott_azonosito;";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.Parameters.AddWithValue("@alkalmazott_azonosito", p_alkalmazott_azonosito);
                using (var reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    try
                    {
                        lb_AlkTelepulesNeve.Text = reader.GetString("telepules_neve");
                        lb_AlkCim.Text = reader.GetString("cim");
                        lb_AlkIranyitoszam.Text = reader.IsDBNull("iranyitoszam") ? "" : reader.GetInt32("iranyitoszam").ToString();

                    }
                    catch (System.InvalidOperationException ex)
                    {
                        lb_AlkTelepulesNeve.Text = "";
                        lb_AlkCim.Text = "";
                        lb_AlkIranyitoszam.Text = "";
                    }

                }
            }
        }

        private void szabadsag_lekerdezese(int p_alkalmazott_azonosito, int p_aktualis_ev)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "SELECT * FROM alkalmazott_eves_szabadsaga WHERE alkalmazott_azonosito = @alkalmazott_azonosito AND ev = @aktualis_ev;";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.Parameters.AddWithValue("@alkalmazott_azonosito", p_alkalmazott_azonosito);
                cmd.Parameters.AddWithValue("@aktualis_ev", p_aktualis_ev);
                using (var reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    try
                    {
                        lb_AlkEvesSzabadsag.Text = reader.IsDBNull("szabadnapok_szama") ? "" : reader.GetInt32("szabadnapok_szama").ToString();

                    }
                    catch (System.InvalidOperationException ex)
                    {
                        lb_AlkEvesSzabadsag.Text = "";
                    }
                }
            }
        }

        private void lb_Adminisztrator_DoubleClick(object sender, EventArgs e)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "adminisztrator_csere";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                cmd.Parameters.AddWithValue("p_jelenlegi_ertek", lb_AlkAdminisztrator.Text);
                cmd.ExecuteNonQuery();
                dgv_Alkalmazottak_SelectionChanged(sender, e);
            }
        }

        private void btn_AlkalmazottAdatainakModositasa_Click(object sender, EventArgs e)
        {
            lb_AlkSzuletesiNev.Visible = false;
            lb_AlkSzuletesiHely.Visible = false;
            lb_AlkSzuletesiIdo.Visible = false;
            lb_AlkAnyjaNeve.Visible = false;
            lb_AlkBeosztas.Visible = false;
            lb_AlkEmail.Visible = false;
            lb_AlkAdoazonositoJel.Visible = false;
            lb_AlkVezeto.Visible = false;
            lb_AlkHomeOfficeLehetoseg.Visible = false;
            lb_AlkEngedelyezo.Visible = false;

            tb_AlkSzuletesiNev.Visible = true;
            tb_AlkSzuletesiNev.Text = lb_AlkSzuletesiNev.Text;
            tb_AlkSzuletesiHely.Visible = true;
            tb_AlkSzuletesiHely.Text = lb_AlkSzuletesiHely.Text;
            dtp_AlkSzuletesiIdo.Visible = true;
            dtp_AlkSzuletesiIdo.Text = lb_AlkSzuletesiIdo.Text;
            tb_AlkAnyjaNeve.Visible = true;
            tb_AlkAnyjaNeve.Text = lb_AlkAnyjaNeve.Text;
            tb_AlkBeosztas.Visible = true;
            tb_AlkBeosztas.Text = lb_AlkBeosztas.Text;
            tb_AlkEmail.Visible = true;
            tb_AlkEmail.Text = lb_AlkEmail.Text;
            tb_AlkAdoazonositoJel.Visible = true;
            tb_AlkAdoazonositoJel.Text = lb_AlkAdoazonositoJel.Text;
            cb_AlkVezeto.Visible = true;
            cb_AlkVezeto.Text = lb_AlkVezeto.Text;
            cb_AlkHomeOfficeLehetoseg.Visible = true;
            cb_AlkHomeOfficeLehetoseg.Text = lb_AlkHomeOfficeLehetoseg.Text;
            cb_AlkEngedelyezo.Visible = true;
            engedelyezolista_feltoltese();
            cb_AlkEngedelyezo.Text = lb_AlkEngedelyezo.Text;

            btn_AlkalmazottAdatainakModositasaMentes.Visible = true;
            btn_AlkalmazottAdatainakModositasaMegsem.Visible = true;
            btn_AlkalmazottAdatainakModositasa.Visible = false;
        }

        private void engedelyezolista_feltoltese()
        {
            cb_AlkEngedelyezo.Items.Clear();
            cb_AlkEngedelyezo_azonosito_lista.Clear();

            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "SELECT * FROM alkalmazott WHERE vezeto = 'I' AND kilepes_datuma IS NULL;";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cb_AlkEngedelyezo.Items.Add(reader.GetString("szuletesi_nev") + " (" + reader.GetString("beosztas") + ")");
                        cb_AlkEngedelyezo_azonosito_lista.Add(reader.GetInt32("alkalmazott_azonosito"));
                    }
                }
            }
        }

        private void btn_AlkalmazottAdatainakModositasaMegsem_Click(object sender, EventArgs e)
        {
            lb_AlkSzuletesiNev.Visible = true;
            lb_AlkSzuletesiHely.Visible = true;
            lb_AlkSzuletesiIdo.Visible = true;
            lb_AlkAnyjaNeve.Visible = true;
            lb_AlkBeosztas.Visible = true;
            lb_AlkEmail.Visible = true;
            lb_AlkAdoazonositoJel.Visible = true;
            lb_AlkVezeto.Visible = true;
            lb_AlkHomeOfficeLehetoseg.Visible = true;
            lb_AlkEngedelyezo.Visible = true;

            tb_AlkSzuletesiNev.Visible = false;
            tb_AlkSzuletesiHely.Visible = false;
            dtp_AlkSzuletesiIdo.Visible = false;
            tb_AlkAnyjaNeve.Visible = false;
            tb_AlkBeosztas.Visible = false;
            tb_AlkEmail.Visible = false;
            tb_AlkAdoazonositoJel.Visible = false;
            cb_AlkVezeto.Visible = false;
            cb_AlkHomeOfficeLehetoseg.Visible = false;
            cb_AlkEngedelyezo.Visible = false;

            btn_AlkalmazottAdatainakModositasaMentes.Visible = false;
            btn_AlkalmazottAdatainakModositasaMegsem.Visible = false;
            btn_AlkalmazottAdatainakModositasa.Visible = true;
        }

        private void btn_AlkalmazottAdatainakModositasaMentese_Click(object sender, EventArgs e)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "alkalmazott_adatainak_modositasa";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                cmd.Parameters.AddWithValue("p_modositott_nev", tb_AlkSzuletesiNev.Text);
                cmd.Parameters.AddWithValue("p_modositott_szuletesi_hely", tb_AlkSzuletesiHely.Text);
                cmd.Parameters.AddWithValue("p_modositott_szuletesi_ido", dtp_AlkSzuletesiIdo.Value.ToString(@"yyyy\-MM\-dd"));
                cmd.Parameters.AddWithValue("p_modositott_anyja_neve", tb_AlkAnyjaNeve.Text);
                cmd.Parameters.AddWithValue("p_modositott_beosztas", tb_AlkBeosztas.Text);
                cmd.Parameters.AddWithValue("p_modositott_email", tb_AlkEmail.Text);
                cmd.Parameters.AddWithValue("p_modositott_adoazonositojel", tb_AlkAdoazonositoJel.Text);
                cmd.Parameters.AddWithValue("p_modositott_vezeto", cb_AlkVezeto.Text);
                cmd.Parameters.AddWithValue("p_modositott_homeoffice", cb_AlkHomeOfficeLehetoseg.Text);
                cmd.Parameters.AddWithValue("p_modositott_engedelyezo", cb_AlkEngedelyezo_azonosito_lista[cb_AlkEngedelyezo.SelectedIndex]);
                cmd.ExecuteNonQuery();
                dgv_Alkalmazottak_SelectionChanged(sender, e);
            }
            btn_AlkalmazottAdatainakModositasaMegsem_Click(sender, e);
        }

        private void btn_LakcimModositasa_Click(object sender, EventArgs e)
        {
            lb_AlkTelepulesNeve.Visible = false;
            lb_AlkCim.Visible = false;
            lb_AlkIranyitoszam.Visible = false;

            tb_AlkTelepulesNeve.Visible = true;
            tb_AlkTelepulesNeve.Text = lb_AlkTelepulesNeve.Text;
            tb_AlkCim.Visible = true;
            tb_AlkCim.Text = lb_AlkCim.Text;
            tb_AlkIranyitoszam.Visible = true;
            tb_AlkIranyitoszam.Text = lb_AlkIranyitoszam.Text;

            btn_LakcimModositasaMentes.Visible = true;
            btn_LakcimModositasaMegsem.Visible = true;
            btn_LakcimModositasa.Visible = false;
        }

        private void btn_LakcimModositasaMegsem_Click(object sender, EventArgs e)
        {
            lb_AlkTelepulesNeve.Visible = true;
            lb_AlkCim.Visible = true;
            lb_AlkIranyitoszam.Visible = true;

            tb_AlkTelepulesNeve.Visible = false;
            tb_AlkCim.Visible = false;
            tb_AlkIranyitoszam.Visible = false;

            btn_LakcimModositasaMentes.Visible = false;
            btn_LakcimModositasaMegsem.Visible = false;
            btn_LakcimModositasa.Visible = true;
        }

        private void btn_LakcimModositasaMentese_Click(object sender, EventArgs e)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "alkalmazott_lakcimenek_modositasa";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                cmd.Parameters.AddWithValue("p_modositott_telepules_neve", tb_AlkTelepulesNeve.Text);
                cmd.Parameters.AddWithValue("p_modositott_cim", tb_AlkCim.Text);
                cmd.Parameters.AddWithValue("p_modositott_iranyitoszam", tb_AlkIranyitoszam.Text);
                cmd.ExecuteNonQuery();
                dgv_Alkalmazottak_SelectionChanged(sender, e);
            }
            btn_LakcimModositasaMegsem_Click(sender, e);
        }

        private void tb_AlkIranyitoszam_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btn_MunkaviszonyModositasa_Click(object sender, EventArgs e)
        {
            lb_AlkMunkaviszonyKezdete.Visible = false;
            lb_AlkMunkaviszonyVege.Visible = false;

            dtp_AlkMunkaviszonyKezdete.Visible = true;
            if (lb_AlkMunkaviszonyKezdete.Text != "")
                dtp_AlkMunkaviszonyKezdete.Text = lb_AlkMunkaviszonyKezdete.Text;
            else dtp_AlkMunkaviszonyKezdete.Text = DateTime.Today.ToString();

            dtp_AlkMunkaviszonyVege.Visible = true;
            if (lb_AlkMunkaviszonyVege.Text != "")
                dtp_AlkMunkaviszonyVege.Text = lb_AlkMunkaviszonyVege.Text;
            else dtp_AlkMunkaviszonyVege.Text = DateTime.Today.ToString();
            btn_MunkaviszonyModositasaMentes.Visible = true;
            btn_MunkaviszonyModositasaMegsem.Visible = true;
            btn_MunkaviszonyModositasa.Visible = false;
        }

        private void btn_MunkaviszonyModositasaMegsem_Click(object sender, EventArgs e)
        {
            lb_AlkMunkaviszonyKezdete.Visible = true;
            lb_AlkMunkaviszonyVege.Visible = true;

            dtp_AlkMunkaviszonyKezdete.Visible = false;
            dtp_AlkMunkaviszonyVege.Visible = false;

            btn_MunkaviszonyModositasaMentes.Visible = false;
            btn_MunkaviszonyModositasaMegsem.Visible = false;
            btn_MunkaviszonyModositasa.Visible = true;
        }

        private void btn_MunkaviszonyModositasaMentes_Click(object sender, EventArgs e)
        {

            if (dtp_AlkMunkaviszonyKezdete.Value < dtp_AlkMunkaviszonyVege.Value)
            {
                using (var mc_mysqlcon = new MySqlConnection(Program.constr))
                {
                    mc_mysqlcon.Open();
                    String sql = "alkalmazott_munkaviszonyanak_modositasa";
                    var cmd = new MySqlCommand(sql, mc_mysqlcon);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                    cmd.Parameters.AddWithValue("p_modositott_munkaviszony_kezdete", dtp_AlkMunkaviszonyKezdete.Value.ToString(@"yyyy\-MM\-dd"));
                    cmd.Parameters.AddWithValue("p_modositott_munkaviszony_vege", dtp_AlkMunkaviszonyVege.Value.ToString(@"yyyy\-MM\-dd"));
                    cmd.ExecuteNonQuery();
                    dgv_Alkalmazottak_SelectionChanged(sender, e);
                }
                btn_MunkaviszonyModositasaMegsem_Click(sender, e);
            }
            else MessageBox.Show("A munkaviszony vége nem lehet korábbi mint a munkaviszony kezdete!");
        }

        private void btn_MunkaidoModositas_Click(object sender, EventArgs e)
        {
            lb_AlkMunkaidoKezdete.Visible = false;
            lb_AlkMunkaidoVege.Visible = false;
            lb_AlkEbedszunetKezdete.Visible = false;
            lb_AlkEbedszunetVege.Visible = false;

            cb_AlkMunkaidoKezdete.Visible = true;
            if (lb_AlkMunkaidoKezdete.Text != "")
                cb_AlkMunkaidoKezdete.Text = lb_AlkMunkaidoKezdete.Text;
            else cb_AlkMunkaidoKezdete.Text = "08:00";

            cb_AlkMunkaidoVege.Visible = true;
            if (lb_AlkMunkaidoVege.Text != "")
                cb_AlkMunkaidoVege.Text = lb_AlkMunkaidoVege.Text;
            else cb_AlkMunkaidoVege.Text = "16:30"; //vagy DateTime.Now.ToString();?!

            cb_AlkEbedidoKezdete.Visible = true;
            if (lb_AlkEbedszunetKezdete.Text != "")
                cb_AlkEbedidoKezdete.Text = lb_AlkEbedszunetKezdete.Text;
            else cb_AlkEbedidoKezdete.Text = "12:00"; //vagy DateTime.Now.ToString();?!

            cb_AlkEbedidoVege.Visible = true;
            if (lb_AlkEbedszunetVege.Text != "")
                cb_AlkEbedidoVege.Text = lb_AlkEbedszunetVege.Text;
            else cb_AlkEbedidoVege.Text = "12:30"; //vagy DateTime.Now.ToString();?!

            btn_MunkaidoModositasMentes.Visible = true;
            btn_MunkaidoModositasMegsem.Visible = true;
            btn_MunkaidoModositas.Visible = false;

            if ((lb_AlkMunkaidoKezdete.Text == "") && (lb_AlkMunkaidoVege.Text == "") && (lb_AlkEbedszunetKezdete.Text == "") && (lb_AlkEbedszunetVege.Text == ""))
            {
                btn_MunkaidoModositasMentes.Click -= btn_MunkaidoModositasMentes_Click;
                btn_MunkaidoModositasMentes.Click += btn_MunkaidoUjMentes_Click;
            }
        }

        private void btn_MunkaidoModositasMegsem_Click(object sender, EventArgs e)
        {
            lb_AlkMunkaidoKezdete.Visible = true;
            lb_AlkMunkaidoVege.Visible = true;
            lb_AlkEbedszunetKezdete.Visible = true;
            lb_AlkEbedszunetVege.Visible = true;

            cb_AlkMunkaidoKezdete.Visible = false;
            cb_AlkMunkaidoVege.Visible = false;
            cb_AlkEbedidoKezdete.Visible = false;
            cb_AlkEbedidoVege.Visible = false;

            btn_MunkaidoModositasMentes.Visible = false;
            btn_MunkaidoModositasMegsem.Visible = false;
            btn_MunkaidoModositas.Visible = true;
        }

        private bool idoEllenorzes()
        {
            TimeOnly MunkaidoKezdete = TimeOnly.Parse(cb_AlkMunkaidoKezdete.Text);
            TimeOnly MunkaidoVege = TimeOnly.Parse(cb_AlkMunkaidoVege.Text);
            TimeOnly EbedidoKezdete = TimeOnly.Parse(cb_AlkEbedidoKezdete.Text);
            TimeOnly EbedidoVege = TimeOnly.Parse(cb_AlkEbedidoVege.Text);

            if (!((MunkaidoKezdete < EbedidoKezdete) &&
                (EbedidoKezdete < EbedidoVege) &&
                (EbedidoVege < MunkaidoVege))) return false;
            return true;
        }

        private void btn_MunkaidoModositasMentes_Click(object sender, EventArgs e)
        {

            if (idoEllenorzes())
            {
                using (var mc_mysqlcon = new MySqlConnection(Program.constr))
                {
                    mc_mysqlcon.Open();
                    String sql = "alkalmazott_munkaidejenek_modositasa";
                    var cmd = new MySqlCommand(sql, mc_mysqlcon);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                    cmd.Parameters.AddWithValue("p_modositott_munkaido_kezdete", cb_AlkMunkaidoKezdete.Text);
                    cmd.Parameters.AddWithValue("p_modositott_munkaido_vege", cb_AlkMunkaidoVege.Text);
                    cmd.Parameters.AddWithValue("p_modositott_ebedido_kezdete", cb_AlkEbedidoKezdete.Text);
                    cmd.Parameters.AddWithValue("p_modositott_ebedido_vege", cb_AlkEbedidoVege.Text);
                    cmd.ExecuteNonQuery();
                    dgv_Alkalmazottak_SelectionChanged(sender, e);
                }
                btn_MunkaidoModositasMegsem_Click(sender, e);
            }
            else MessageBox.Show("Kérem ellenőrizze a megadott időpontokat!");
        }

        private void btn_MunkaidoUjMentes_Click(object sender, EventArgs e)
        {
            if (idoEllenorzes())
            {
                using (var mc_mysqlcon = new MySqlConnection(Program.constr))
                {
                    mc_mysqlcon.Open();
                    String sql = "alkalmazott_munkaidejenek_felvitele";
                    var cmd = new MySqlCommand(sql, mc_mysqlcon);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                    cmd.Parameters.AddWithValue("p_munkaido_kezdete", cb_AlkMunkaidoKezdete.Text);
                    cmd.Parameters.AddWithValue("p_munkaido_vege", cb_AlkMunkaidoVege.Text);
                    cmd.Parameters.AddWithValue("p_ebedido_kezdete", cb_AlkEbedidoKezdete.Text);
                    cmd.Parameters.AddWithValue("p_ebedido_vege", cb_AlkEbedidoVege.Text);
                    cmd.ExecuteNonQuery();
                    dgv_Alkalmazottak_SelectionChanged(sender, e);
                }
                btn_MunkaidoModositasMegsem_Click(sender, e);

                btn_MunkaidoModositasMentes.Click -= btn_MunkaidoUjMentes_Click;
                btn_MunkaidoModositasMentes.Click += btn_MunkaidoModositasMentes_Click;
            }
            else MessageBox.Show("Kérem ellenőrizze a megadott időpontokat!");
        }

        private void btn_UjAlkalmazott_Click(object sender, EventArgs e)
        {
            frm_UjAlkalmazott frm_Uj = new frm_UjAlkalmazott();
            frm_Uj.ShowDialog();
            dgv_Alkalmazottak_SelectionChanged(sender, e);
        }

        private void tb_AlkIranyitoszam_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Tab)
            {
                e.IsInputKey = true;
                this.ActiveControl = tb_AlkTelepulesNeve;
            }
        }

        private void tb_AlkEvesSzabadsag_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btn_SzabadsagModositas_Click(object sender, EventArgs e)
        {
            lb_AlkEvesSzabadsag.Visible = false;
            tb_AlkEvesSzabadsag.Visible = true;
            tb_AlkEvesSzabadsag.Text = lb_AlkEvesSzabadsag.Text;

            btn_SzabadsagModositasMentes.Visible = true;
            btn_SzabadsagModositasMegsem.Visible = true;
            btn_SzabadsagModositas.Visible = false;
        }

        private void btn_SzabadsagModositasMegsem_Click(object sender, EventArgs e)
        {
            lb_AlkEvesSzabadsag.Visible = true;
            tb_AlkEvesSzabadsag.Visible = false;

            btn_SzabadsagModositasMentes.Visible = false;
            btn_SzabadsagModositasMegsem.Visible = false;
            btn_SzabadsagModositas.Visible = true;
        }

        private void btn_SzabadsagModositasMentes_Click(object sender, EventArgs e)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();

                if (lb_AlkEvesSzabadsag.Text == "")
                {
                    String sql = "alkalmazott_szabadsaganak_felvitele";
                    var cmd = new MySqlCommand(sql, mc_mysqlcon);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                    cmd.Parameters.AddWithValue("p_ev", DateTime.Now.Year);
                    cmd.Parameters.AddWithValue("p_szabadnapok_szama", tb_AlkEvesSzabadsag.Text);
                    cmd.ExecuteNonQuery();
                    dgv_Alkalmazottak_SelectionChanged(sender, e);
                }
                else
                {
                    String sql = "alkalmazott_szabadsaganak_modositasa";
                    var cmd = new MySqlCommand(sql, mc_mysqlcon);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                    cmd.Parameters.AddWithValue("p_ev", DateTime.Now.Year);
                    cmd.Parameters.AddWithValue("p_szabadnapok_szama", tb_AlkEvesSzabadsag.Text);
                    cmd.ExecuteNonQuery();
                    dgv_Alkalmazottak_SelectionChanged(sender, e);
                }
                btn_SzabadsagModositasMegsem_Click(sender, e);
            }
        }

        private void btn_JelszoReset_Click(object sender, EventArgs e)
        {
            try
            {
                using (var mc_mysqlcon = new MySqlConnection(Program.constr))
                {
                    mc_mysqlcon.Open();
                    String sql = "alkalmazott_jelszo_reset";
                    var cmd = new MySqlCommand(sql, mc_mysqlcon);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Jelszó sikeresen visszaállítva!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Jelszó visszaállítása sikertelen!");
            }
        }

        private void btn_MunkaidoJovahagyas_Click(object sender, EventArgs e)
        {
            frm_MunkaidoJovahagyas frm_MunkaidoJovahagyas = new frm_MunkaidoJovahagyas();
            frm_MunkaidoJovahagyas.ShowDialog();
        }

        private void btn_IgenylesJovahagyas_Click(object sender, EventArgs e)
        {
            frm_IgenylesJovahagyas frm_IgenylesJovahagyas = new frm_IgenylesJovahagyas();
            frm_IgenylesJovahagyas.ShowDialog();
        }

        private void btn_FelhasznalhatoSzabadsag_Click(object sender, EventArgs e)
        {
            using (var mc_mysqlcon = new MySqlConnection(Program.constr))
            {
                mc_mysqlcon.Open();
                String sql = "felhasznalt_szabadsag_homeoffice";
                var cmd = new MySqlCommand(sql, mc_mysqlcon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("p_alkalmazott_azonosito", alkalmazott_azonosito);
                cmd.Parameters.AddWithValue("p_ev", DateTime.Now.Year.ToString());
                cmd.Parameters.AddWithValue("p_statusz", "szabadság");
                cmd.Parameters.Add("@felhasznaltSzabadnapokSzama", MySqlDbType.Int32);
                cmd.Parameters["@felhasznaltSzabadnapokSzama"].Direction = ParameterDirection.ReturnValue;

                int felhasznaltSzabadnapokSzama = int.Parse(cmd.ExecuteScalar().ToString());
                int evesSzabadnapokSzama = int.Parse(lb_AlkEvesSzabadsag.Text);
                int felhasznalhatoSzabadnapokSzama = evesSzabadnapokSzama - felhasznaltSzabadnapokSzama;

                MessageBox.Show("Az alkalmazott éves szabadnapjainak száma: "+ evesSzabadnapokSzama.ToString() +
                    Environment.NewLine + "Eddig felhasznált szabadnapjainak száma: "+ felhasznaltSzabadnapokSzama.ToString() + 
                    Environment.NewLine + "Továbbiakban felhasználható szabadnapjainak száma: " + felhasznalhatoSzabadnapokSzama.ToString());
            }
        }
    }
}

